import os
import pickle
import numpy as np
import torch

def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)


class ENV(object):

    def __init__(self, normalizer, seed, data_path, cids, max_article_chars=None):

        if os.path.exists(data_path):
            with open(data_path, 'rb') as f:
                cached_results = pickle.load(f)
        else:
            print(f"Error in loading cached vec env {data_path}")
            return

        if len(cids) == 0:
            all_data = cached_results
        else:
            all_data = {cid: cached_results[cid] for cid in cids}

        print(f"Loaded {len(all_data)} trajectories for ENV.")

        self.normalizer = normalizer
        self.pending_rewards = []

        self.trajectories = {}
        skipped_long = []

        for k, value in all_data.items():

            sentences = value["sentences"]
            article_text = " ".join(sentences)

            if max_article_chars is not None and len(article_text) > max_article_chars:
                skipped_long.append(k)
                continue

            h_doc = value["full_text_embedding"]
            h_t = value["sentence_embeddings"]

            self.trajectories[k] = {"cid":k,
                                    "sentences": sentences,
                                    "h_doc": h_doc,
                                    "sentence_embeddings": h_t,
                                    "num_sent": len(sentences),
                                    "selected_sentences": [],
                                    "selected_sentences_emb": [],
                                    "current_sentence_idx": 0,
                                    "label": value["label"],
                                    "published_date": value["published_date"],
                                    "article": article_text}


        self.trajectories_ids = list(self.trajectories.keys())

        self.current_traj = None
        self.traj_step = None
            
        set_seed(seed=seed)


    @staticmethod
    def assign_episode_rewards(actions, prediction_correct,
                               reward_choose=0.05, reward_skip=0.02,
                               terminal_reward=3.0, sparsity_penalty=0.5,
                               ground_truth="fake"):
        if ground_truth == "real":
            sign = 0.0
            effective_terminal_reward = 0.0
        else:
            sign = 1.0 if prediction_correct else -1.0
            effective_terminal_reward = terminal_reward

        num_selected = sum(1 for a in actions if a == 1)
        num_total = len(actions)
        selection_ratio = num_selected / num_total
        penalty = selection_ratio * sparsity_penalty 

        rewards = []
        for i, action in enumerate(actions):

            if action == 1:
                r = sign * reward_choose
            else: 
                r = sign * reward_skip

            if i == len(actions) - 1:
                r += sign * effective_terminal_reward
                r -= penalty 

            rewards.append(r)

        return rewards

    def reset(self, traj_id=None):
        if traj_id is not None:
            self.current_traj = traj_id
        else:
            np.random.shuffle(self.trajectories_ids)
            self.current_traj = self.trajectories_ids[0]

        self.trajectories[self.current_traj]["selected_sentences"] = []
        self.trajectories[self.current_traj]["selected_sentences_emb"] = []
        self.trajectories[self.current_traj]["current_sentence_idx"] = 0

        first_sentence_emb = self.trajectories[self.current_traj]["sentence_embeddings"][0]
        
        self.traj_step = 0
        self.current_traj_len = len(self.trajectories[self.current_traj]["sentences"])

        h_bar = np.zeros_like(first_sentence_emb)

        e_t = np.array([(self.traj_step+1) / self.current_traj_len])

        first_obs = np.concatenate([first_sentence_emb, h_bar, self.trajectories[self.current_traj]["h_doc"], e_t])
        
        first_obs = self.normalizer._obfilt(first_obs)
        return torch.tensor(first_obs)
    
    def step(self, action):

        current_act = action[0][0].item()

        current_traj_data = self.trajectories[self.current_traj]
        current_sentence_idx = current_traj_data["current_sentence_idx"]

        if current_act == 1:
            current_sentence = current_traj_data["sentences"][current_sentence_idx]
            current_sentence_emb = current_traj_data["sentence_embeddings"][current_sentence_idx]
            current_traj_data["selected_sentences"].append(current_sentence)
            current_traj_data["selected_sentences_emb"].append(current_sentence_emb)
        elif current_act == 0:
            pass  

        current_traj_data["current_sentence_idx"] += 1
        self.traj_step += 1

        terminated = current_traj_data["current_sentence_idx"] >= len(current_traj_data["sentences"])

        reward = 0.0  # placeholder

        if not terminated:
            next_sentence_idx = current_traj_data["current_sentence_idx"]
            next_sentence_emb = current_traj_data["sentence_embeddings"][next_sentence_idx]  # h_t

            if len(current_traj_data["selected_sentences_emb"]) > 0:
                h_bar = np.mean(current_traj_data["selected_sentences_emb"], axis=0)
            else:
                h_bar = np.zeros_like(next_sentence_emb)

            e_t = np.array([(self.traj_step+1) / self.current_traj_len])
            next_obs = np.concatenate([next_sentence_emb, h_bar, self.trajectories[self.current_traj]["h_doc"], e_t])
            next_obs = self.normalizer._obfilt(next_obs)

        else:
            dummy_sentence_emb = current_traj_data["sentence_embeddings"][0]
            next_obs = np.concatenate([np.zeros_like(dummy_sentence_emb),
                                       np.zeros_like(dummy_sentence_emb),
                                       self.trajectories[self.current_traj]["h_doc"],
                                       np.array([1.0])])
            next_obs = self.normalizer._obfilt(next_obs)

        next_obs = torch.tensor(next_obs)
        return next_obs, torch.tensor([reward]), [terminated], [{}]
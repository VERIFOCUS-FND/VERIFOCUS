import os
import json
import pickle
import time
import numpy as np
import datetime
import torch
import wandb

_wandb_init_kwargs = {}

_MAX_ARTICLE_CHARS = 9120 * 4 - 1000 - 10000  # = 25480

def _safe_wandb_log(data, **kwargs):
    try:
        wandb.log(data, **kwargs)
    except Exception as e:
        print(f"[wandb] Failed to log metrics: {e}")
        if _wandb_init_kwargs:
            try:
                print("[wandb] Finishing broken run and reinitializing wandb...")
                try:
                    wandb.finish(exit_code=1, quiet=True)
                except Exception:
                    pass
                wandb.init(**_wandb_init_kwargs)
                wandb.log(data, **kwargs)
                print("[wandb] Reinitialized and logged successfully.")
            except Exception as e2:
                print(f"[wandb] Reinitialization also failed: {e2}")

from a2c_ppo_acktr import algo, utils
from a2c_ppo_acktr.arguments import get_args
from a2c_ppo_acktr.envs import VecNormalize
from a2c_ppo_acktr.model import Policy
from a2c_ppo_acktr.storage import RolloutStorage
from env import ENV
from compute_reward import call_inference_api_with_custom_data, check_api_status, create_sample_custom_data_list
from stage2_training_manager import Stage2TrainingManager


def prepare_input_prompts(config, actor_critic, obs_rms, num_processes, device, split="test", norm_obs=True, num_samples=1):

    if split == "test":
        test_data = json.load(open(config['paths']['test_data_path'], 'r'))
        test_cids = [item["docid"] for item in test_data]
    else:
        test_data = json.load(open(config['paths']['data_path'], 'r'))
        test_cids = [item["docid"] for item in test_data]

    data_path = config['paths']['cache_file']

    actor_critic = actor_critic.to(device)

    vec_norm = VecNormalize(observation_space_shape=(config['model']['OBS_DIM'],), norm_obs=norm_obs)

    eval_envs = ENV(vec_norm, config['training']['seed'], data_path, test_cids, max_article_chars=_MAX_ARTICLE_CHARS)

    input_prompts = {}

    use_deterministic = (num_samples == 1)

    with torch.no_grad():
        if vec_norm is not None:
            vec_norm.eval()
            vec_norm.obs_rms = obs_rms

        eval_ids = eval_envs.trajectories_ids

        for trajectory_id in eval_ids:
            for k in range(num_samples):

                STOP = False
                obs = eval_envs.reset(trajectory_id).to(device).unsqueeze(0)
                eval_recurrent_hidden_states = torch.zeros(
                    num_processes, actor_critic.recurrent_hidden_state_size, device=device)
                eval_masks = torch.zeros(num_processes, 1, device=device)

                while not STOP:

                    with torch.no_grad():
                        _, action, _, eval_recurrent_hidden_states = actor_critic.act(
                            obs.to(device),
                            eval_recurrent_hidden_states.to(device),
                            eval_masks.to(device),
                            deterministic=use_deterministic)

                    obs, _, done, _ = eval_envs.step(action)
                    obs = obs.unsqueeze(0)

                    eval_masks = torch.tensor(
                        [[0.0] if done_ else [1.0] for done_ in done],
                        dtype=torch.float32,
                        device=device)

                    STOP = False
                    if done[0]:
                        STOP = True

                label = eval_envs.trajectories[trajectory_id]["label"]
                selected_sentences = eval_envs.trajectories[trajectory_id]["selected_sentences"]
                ground_truth_str = "real" if label == 1 else "fake"
                published_date = eval_envs.trajectories[trajectory_id]["published_date"]
                if hasattr(published_date, 'strftime'):
                    published_date = published_date.strftime("%Y-%m-%d")
                sample_key = trajectory_id if num_samples == 1 else f"{trajectory_id}_s{k}"
                input_prompts[sample_key] = {
                    "selected_sentences": selected_sentences,
                    "article_id": trajectory_id,
                    "trajectory_id": trajectory_id,
                    "published_date": published_date,
                    "article_text": eval_envs.trajectories[trajectory_id]["article"],
                    "ground_truth": ground_truth_str,
                    "split": "test"
                }

    assert len(input_prompts) == len(eval_ids) * num_samples
    del eval_envs
    return input_prompts


def evaluation(config, actor_critic, obs_rms, num_processes, device, norm_obs=True):

    input_prompts = prepare_input_prompts(config, actor_critic, obs_rms, num_processes, device, split="test", norm_obs=norm_obs)

    infer_results = call_inference_api_with_custom_data(
        list(input_prompts.values()),
        host=config['training']['reward_api_url'],
        port=config['training'].get('reward_api_port', 8001))

    return infer_results


def load_checkpoint(checkpoint_path, actor_critic, agent, normalizer, device):
    print(f"Loading checkpoint from: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)

    actor_critic.load_state_dict(checkpoint['actor_critic_state_dict'])
    agent.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    obs_rms = checkpoint.get('obs_rms', None)
    start_iteration = checkpoint['iteration']
    total_num_steps = checkpoint.get('total_num_steps', [])
    wandb_run_id = checkpoint.get('wandb_run_id', None)

    print(f"Resuming from iteration {start_iteration}")
    print(f"Total steps so far: {sum(total_num_steps) if total_num_steps else 0}")
    if wandb_run_id:
        print(f"Will resume wandb run: {wandb_run_id}")

    return start_iteration, total_num_steps, obs_rms, wandb_run_id


def main(config):
    os.environ["CUDA_DEVICE_ORDER"] = config['environment']['CUDA_DEVICE_ORDER']
    os.environ["CUDA_VISIBLE_DEVICES"] = config['environment']['CUDA_VISIBLE_DEVICES']

    TIMESTAMP = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"Start Training: {TIMESTAMP}")
    print(config)

    wandb_run_id = None

    args = get_args()

    torch.manual_seed(config['training']['seed'])
    torch.cuda.manual_seed_all(config['training']['seed'])

    if config['training']['cuda'] and torch.cuda.is_available() and config['training']['cuda_deterministic']:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True

    torch.set_num_threads(1)
    device = torch.device("cuda" if config['training']['cuda'] else "cpu")

    actor_critic = Policy(
        config['model']['OBS_DIM'],
        config['model']['ACT_DIM'],
        base_kwargs={'recurrent': args.recurrent_policy})
    actor_critic.to(device)

    agent = algo.PPO(
        actor_critic,
        config['training']['clip_param'],
        config['training']['ppo_epoch'],
        config['training']['num_mini_batch'],
        config['training']['value_loss_coef'],
        config['training']['entropy_coef'],
        lr=config['training']['lr'],
        eps=config['training']['eps'],
        max_grad_norm=config['training']['max_grad_norm'])

    normalizer = VecNormalize((config['model']['OBS_DIM'],), norm_obs=config['training']['norm_obs'])

    start_iteration = 0
    total_num_steps = []
    checkpoint_path = config['training'].get('resume_from_checkpoint', None)

    if checkpoint_path and os.path.exists(checkpoint_path):
        start_iteration, total_num_steps, loaded_obs_rms, wandb_run_id = load_checkpoint(
            checkpoint_path, actor_critic, agent, normalizer, device
        )
        if loaded_obs_rms is not None:
            normalizer.obs_rms = loaded_obs_rms
    elif checkpoint_path:
        print(f"\nWarning: Checkpoint path specified but file not found: {checkpoint_path}")
        print("Starting training from scratch...\n")

    if wandb_run_id is None:
        base_name = f"stage1_{config['dataset']['dataset_type']}_seed{config['training']['seed']}"
        wandb_run_id = f"{base_name}_{TIMESTAMP}"
        print(f"Starting new training run with wandb ID: {wandb_run_id}")

    if config['training'].get('use_wandb', True):
        global _wandb_init_kwargs
        _wandb_init_kwargs = dict(
            project=config['training'].get('wandb_project', 'skyrl-search-training'),
            group=config['training'].get('wandb_group', f"stage1_{config['dataset']['dataset_type']}_seed{config['training']['seed']}"),
            name=f"stage1_{config['dataset']['dataset_type']}_seed{config['training']['seed']}_{TIMESTAMP}",
            config=config,
            tags=[
                'stage1',
                config['dataset']['dataset_type'],
                config['training']['model_type'],
                f"seed{config['training']['seed']}"
            ],
            resume='allow',
            id=wandb_run_id
        )
        wandb.init(**_wandb_init_kwargs)

    cache_file = config['paths']['cache_file']

    train_data = json.load(open(config['paths']['data_path'], 'r'))
    train_cids = [item["docid"] for item in train_data]

    env = ENV(normalizer, config['training']['seed'], cache_file, train_cids, max_article_chars=_MAX_ARTICLE_CHARS)

    stage2_manager = Stage2TrainingManager(
        data_dir=config['training'].get('stage2_data_dir', ""),
        model_path=config['training']['stage2_llm'],
        base_export_path=config['training'].get('stage2_export_path', "$HOME/skyrl_exports"),
        inference_server_host=config['training']['reward_api_url'],
        inference_server_port=config['training'].get('reward_api_port', 8001)
    )
    print(f"Stage 2 Training Manager initialized")

    lora_path = config['training'].get('lora_checkpoint_path', None)
    stage2_manager.start_inference_server(lora_path=lora_path, val_data_path="validation_demo.parquet", wait_for_ready=True)

    if 'reward_api_url' in config.get('training', {}):
        env.reward_api_url = config['training']['reward_api_url']
        env.reward_api_port = config['training'].get('reward_api_port', 8001)
        check_api_status(env.reward_api_url, env.reward_api_port)

    start = time.time()

    num_iteration = config['training']['num_iteration']
    num_step = config['training']['num_steps']
    for j in range(start_iteration, num_iteration):

        obs = env.reset()

        rollouts = RolloutStorage(num_step, args.num_processes,
                                  (config['model']['OBS_DIM'],), config['model']['ACT_DIM'],
                                  actor_critic.recurrent_hidden_state_size)

        rollouts.obs[0].copy_(obs)
        rollouts.to(device)

        if config['training']['use_linear_lr_decay']:
            utils.update_linear_schedule(
                agent.optimizer, j, num_iteration,
                agent.optimizer.lr if config['training']['algo'] == "acktr" else config['training']['lr'])

        episode_start = 0
        episode_actions = []
        episode_boundaries = []

        for step in range(num_step):

            with torch.no_grad():
                value, action, action_log_prob, recurrent_hidden_states = actor_critic.act(
                    rollouts.obs[step], rollouts.recurrent_hidden_states[step],
                    rollouts.masks[step])

            obs, temp_reward, done, infos = env.step(action)

            episode_actions.append(action[0][0].item())

            masks = torch.FloatTensor(
                [[0.0] if done_ else [1.0] for done_ in done])
            bad_masks = torch.FloatTensor(
                [[0.0] if 'bad_transition' in info.keys() else [1.0]
                 for info in infos])

            rollouts.insert(obs, recurrent_hidden_states, action,
                            action_log_prob, value, torch.tensor([0.0]), masks, bad_masks)

            if done[0]:
                current_traj_data = env.trajectories[env.current_traj]
                episode_boundaries.append({
                    'start': episode_start,
                    'end': step,
                    'trajectory_id': env.current_traj,
                    'selected_sentences': current_traj_data["selected_sentences"].copy(),
                    'actions': episode_actions.copy()
                })

                episode_start = step + 1
                episode_actions = []
                obs = env.reset()
                rollouts.obs[rollouts.step].copy_(obs)

        with torch.no_grad():
            next_value = actor_critic.get_value(
                rollouts.obs[-1], rollouts.recurrent_hidden_states[-1],
                rollouts.masks[-1]).detach()

        episode_stats = {
            'total_rewards': [],
            'episode_lengths': [],
            'num_selected': [],
            'predictions_correct': [],
            'choose_counts': [],
            'skip_counts': []
        }

        inference_data = []
        for episode_info in episode_boundaries:
            selected_sentences = episode_info['selected_sentences']
            trajectory_id = episode_info['trajectory_id']
            published_date = env.trajectories[trajectory_id]["published_date"]
            if hasattr(published_date, 'strftime'):
                published_date = published_date.strftime("%Y-%m-%d")
            article_text = env.trajectories[trajectory_id]["article"]
            ground_truth = "real" if env.trajectories[trajectory_id]["label"] == 1 else "fake"
            inference_data.append({
                'selected_sentences': selected_sentences,
                "article_id": trajectory_id,
                'trajectory_id': trajectory_id,
                'published_date': published_date,
                'article_text': article_text,
                'ground_truth': ground_truth,
                'split': "train"
            })

        current_iteration = j
        use_wandb = config['training'].get('use_wandb', True)
        infer_results = call_inference_api_with_custom_data(
                inference_data,
                host=env.reward_api_url,
                port=env.reward_api_port,
                iteration=current_iteration,
                log_to_wandb=use_wandb
            )

        returned_results = {}
        for res in infer_results["processed_results"]:
            returned_results[res["article_id"]] = res["is_correct"]

        ground_truth_map = {d["trajectory_id"]: d["ground_truth"] for d in inference_data}

        for episode_info in episode_boundaries:
            start = episode_info['start']
            end = episode_info['end']
            actions = episode_info['actions']
            selected_sentences = episode_info['selected_sentences']
            trajectory_id = episode_info['trajectory_id']
            prediction_correct = returned_results[trajectory_id]

            ground_truth = ground_truth_map.get(trajectory_id, "fake")

            episode_rewards = ENV.assign_episode_rewards(
                actions=actions,
                prediction_correct=prediction_correct,
                reward_choose=0.05,
                reward_skip=0.02,
                terminal_reward=config['training'].get('terminal_reward', 3.0),
                sparsity_penalty=config['training'].get('sparsity_penalty', 0.5),
                ground_truth=ground_truth,
            )

            for t, reward in enumerate(episode_rewards):
                step_idx = start + t
                if step_idx <= end and step_idx < rollouts.rewards.size(0):
                    rollouts.rewards[step_idx] = torch.tensor([reward])

            episode_stats['total_rewards'].append(sum(episode_rewards))
            episode_stats['episode_lengths'].append(len(actions))
            episode_stats['num_selected'].append(sum(1 for a in actions if a == 1))
            episode_stats['predictions_correct'].append(1 if prediction_correct else 0)
            episode_stats['choose_counts'].append(sum(1 for a in actions if a == 1))
            episode_stats['skip_counts'].append(sum(1 for a in actions if a == 0))

            mid_point = len(actions) // 2
            first_half_actions = actions[:mid_point]
            second_half_actions = actions[mid_point:]

            first_half_choose = sum(1 for a in first_half_actions if a == 1)
            second_half_choose = sum(1 for a in second_half_actions if a == 1)

            if 'first_half_ratios' not in episode_stats:
                episode_stats['first_half_ratios'] = []
                episode_stats['second_half_ratios'] = []

            episode_stats['first_half_ratios'].append(
                first_half_choose / len(first_half_actions) if len(first_half_actions) > 0 else 0
            )
            episode_stats['second_half_ratios'].append(
                second_half_choose / len(second_half_actions) if len(second_half_actions) > 0 else 0
            )

        rollouts.compute_returns(next_value, config['training']['use_gae'], config['training']['gamma'],
                                 config['training']['gae_lambda'], config['training']['use_proper_time_limits'])

        agent.num_mini_batch = config['training']['num_mini_batch']

        value_loss, action_loss, dist_entropy = agent.update(rollouts)
        total_num_steps.append(num_step)

        if config['paths']['save_dir'] != "":
            model_save_path = config['paths']['save_dir']

            try:
                os.makedirs(model_save_path, exist_ok=True)
            except OSError:
                pass

            latest_checkpoint = {
                'iteration': j,
                'actor_critic_state_dict': actor_critic.state_dict(),
                'optimizer_state_dict': agent.optimizer.state_dict(),
                'obs_rms': getattr(normalizer, 'obs_rms', None),
                'total_num_steps': total_num_steps,
                'config': config,
                'timestamp': TIMESTAMP
            }
            latest_checkpoint_path = os.path.join(model_save_path, "latest_checkpoint.pt")
            torch.save(latest_checkpoint, latest_checkpoint_path)
            print(f"Saved latest checkpoint to: {latest_checkpoint_path}")

        if config['training'].get('use_wandb', True):

            with torch.no_grad():
                _, new_log_probs, _, _ = agent.actor_critic.act(
                    rollouts.obs[:-1].view(-1, *rollouts.obs.size()[2:]),
                    rollouts.recurrent_hidden_states[:-1].view(-1, agent.actor_critic.recurrent_hidden_state_size),
                    rollouts.masks[:-1].view(-1, 1)
                )

                old_log_probs = rollouts.action_log_probs.view(-1, 1)
                ratio = torch.exp(new_log_probs - old_log_probs)
                approx_kl = ((ratio - 1) - (new_log_probs - old_log_probs)).mean().item()
                clip_fraction = ((ratio < (1.0 - config['training']['clip_param'])) |
                                 (ratio > (1.0 + config['training']['clip_param']))).float().mean().item()
                advantages = rollouts.returns[:-1] - rollouts.value_preds[:-1]
                adv_mean = advantages.mean().item()
                adv_std = advantages.std().item()

            metrics = {
                'iteration': j,
                'total_timesteps': sum(total_num_steps),
                'train/value_loss': value_loss,
                'train/action_loss': action_loss,
                'train/entropy': dist_entropy,
                'train/learning_rate': agent.optimizer.param_groups[0]['lr'],
                'train/approx_kl': approx_kl,
                'train/clip_fraction': clip_fraction,
                'train/adv_mean': adv_mean,
                'train/adv_std': adv_std,
                'episode/num_episodes': len(episode_boundaries),
            }

            if len(episode_stats['total_rewards']) > 0:
                metrics.update({
                    'reward/episode_reward_mean': np.mean(episode_stats['total_rewards']),
                    'episode/length_mean': np.mean(episode_stats['episode_lengths']),
                    'selection/num_selected_mean': np.mean(episode_stats['num_selected']),
                    'selection/selection_rate': np.mean(episode_stats['choose_counts']) / (np.mean(episode_stats['choose_counts']) + np.mean(episode_stats['skip_counts']) + 1e-8),
                    'action/choose_ratio': np.sum(episode_stats['choose_counts']) / (np.sum(episode_stats['choose_counts']) + np.sum(episode_stats['skip_counts']) + 1e-8),
                    'action/skip_ratio': np.sum(episode_stats['skip_counts']) / (np.sum(episode_stats['choose_counts']) + np.sum(episode_stats['skip_counts']) + 1e-8),
                    'prediction/accuracy': np.mean(episode_stats['predictions_correct']),
                    'prediction/num_correct': np.sum(episode_stats['predictions_correct']),
                    'prediction/num_total': len(episode_stats['predictions_correct']),
                })

            _safe_wandb_log(metrics)

        if (j % config['training']['save_interval'] == 0
                or j == num_iteration - 1 and j != 0) and config['paths']['save_dir'] != "":
            model_save_path = config['paths']['save_dir']

            save_prefix = f"iteration{j}"
            try:
                os.makedirs(model_save_path)
            except OSError:
                pass

            model_file_path = os.path.join(model_save_path, save_prefix + ".pt")
            checkpoint = {
                'iteration': j,
                'actor_critic_state_dict': actor_critic.state_dict(),
                'optimizer_state_dict': agent.optimizer.state_dict(),
                'obs_rms': getattr(normalizer, 'obs_rms', None),
                'total_num_steps': total_num_steps,
                'config': config,
                'timestamp': TIMESTAMP,
                'wandb_run_id': wandb_run_id
            }
            torch.save(checkpoint, model_file_path)

            latest_checkpoint_path = os.path.join(model_save_path, f"iter{j}_checkpoint.pt")
            torch.save(checkpoint, latest_checkpoint_path)
            print(f"Saved checkpoint to: {model_file_path}")
            print(f"Latest checkpoint: {latest_checkpoint_path}")

            if config['training'].get('use_wandb', True):
                wandb.save(model_file_path, base_path=os.path.dirname(model_file_path))
                wandb.save(latest_checkpoint_path, base_path=os.path.dirname(latest_checkpoint_path))
                _safe_wandb_log({
                    'model/saved_iteration': j,
                    'model/saved_timesteps': sum(total_num_steps)
                })

        if j % args.log_interval == 0:
            end = time.time()
            print(
                "Updates {}, num timesteps {}, FPS {} \n Last {} training episodes: dist_entropy {:.6f}, value_loss {:.6f}, action_loss {:.6f}\n"
                .format(j, sum(total_num_steps),
                        int(sum(total_num_steps) / (end - start)),
                        len(total_num_steps),
                        dist_entropy, value_loss,
                        action_loss))


        if j % config['training']['stage2_training_interval'] == 0 and j != 0:
            print("Stage 2 Training Checkpoint at iteration {}\n".format(j))

            if stage2_manager is not None and config['training'].get('enable_stage2_training', False):
                import gc
                gc.collect()
                torch.cuda.empty_cache()

                prepared_training_data = prepare_input_prompts(
                    config, actor_critic, normalizer.obs_rms, args.num_processes, device,
                    split="train", norm_obs=config['training']['norm_obs'],
                    num_samples=config['training'].get('stage2_num_samples', 1))
                prepared_training_data_custom = create_sample_custom_data_list(
                    list(prepared_training_data.values())[0:config['training']['stage2_training_num']],
                    target_count=len(env.trajectories) * config['training'].get('stage2_num_samples', 1))

                stage2_manager.save_training_data(prepared_training_data_custom, prepared_training_data_custom, iteration=j)

                success = stage2_manager.perform_stage2_training_cycle(
                    iteration=j,
                    epochs=config['training'].get('stage2_epochs', 2)
                )

                time.sleep(5)

        if j == num_iteration - 1:

            save_path = config['paths']['save_path'].format(TIMESTAMP=TIMESTAMP)
            save_dir = os.path.dirname(save_path)
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)

            eval_result = evaluation(config, actor_critic, normalizer.obs_rms, args.num_processes,
                                        device, norm_obs=True)

            with open(save_path, 'wb') as f:
                stage1_ckpt = os.path.join(config['paths']['save_dir'], f"export.pt") if config['paths']['save_dir'] else None
                stage2_ckpt = stage2_manager.lora_path if stage2_manager else None
                pickle.dump({
                    'eval_result': eval_result,
                    'config': config,
                    'cache_key': "export",
                    'stage1_checkpoint': stage1_ckpt,
                    'stage2_checkpoint': stage2_ckpt,
                    'iteration': j,
                }, f)
            eval_metrics = eval_result['metrics']
            if config['training'].get('use_wandb', True):
                _safe_wandb_log({
                    'eval/iteration': j,
                    'eval/total_timesteps': sum(total_num_steps),
                    'eval/pass_at_1': eval_metrics.get('eval/all/avg_score', 0),
                    'eval/stage1_checkpoint': stage1_ckpt or 'N/A',
                    'eval/stage2_checkpoint': stage2_ckpt or 'N/A',
                })
            print(f"Eval at iter {j} | stage1_ckpt: {stage1_ckpt} | stage2_ckpt: {stage2_ckpt}")


    if stage2_manager is not None:
        stage2_manager.cleanup()

    if config['training'].get('use_wandb', True):
        wandb.finish()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=2)
    parser.add_argument("--base_dir", type=str, default="./outputs")
    parser.add_argument("--cache_file", type=str, required=True,
                        help="Path to precomputed embeddings .pkl file")
    parser.add_argument("--data_path", type=str, required=True,
                        help="Path to training data .json file")
    parser.add_argument("--test_data_path", type=str, required=True,
                        help="Path to test data .json file")
    parser.add_argument("--lora_checkpoint_path", type=str, default=None,
                        help="Path to a pretrained LoRA checkpoint for Stage 2 (optional)")
    args = parser.parse_args()

    seed = args.seed
    run_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    base_dir = f"{args.base_dir}/seed{seed}_{run_timestamp}"

    config = {
        "environment": {
            "CUDA_DEVICE_ORDER": "PCI_BUS_ID",
            "CUDA_VISIBLE_DEVICES": ""
        },
        "model": {
            "OBS_DIM": 12289,
            "ACT_DIM": 2
        },
        "training": {
            "resume_from_checkpoint": None,
            "stage2_llm": "aidenjhwu/SearchAgent-8B-hq",
            "seed": seed,
            "num_iteration": 160,
            "num_steps": 2000,
            "norm_obs": True,
            "algo": "ppo",
            "model_type": "ppo",
            "temp": 0.05,
            "lr": 3e-4,
            "eps": 1e-5,
            "alpha": 0.99,
            "gamma": 0.99,
            "use_gae": True,
            "gae_lambda": 0.95,
            "entropy_coef": 0.02,
            "value_loss_coef": 0.5,
            "max_grad_norm": 0.5,
            "cuda": True,
            "cuda_deterministic": False,
            "num_processes": 1,
            "ppo_epoch": 4,
            "num_mini_batch": 4,
            "clip_param": 0.2,
            "terminal_reward": 3.0,
            "sparsity_penalty": 0.3,
            "log_interval": 1,
            "save_interval": 20,
            "stage2_training_interval": 20,
            "use_linear_lr_decay": True,
            "use_proper_time_limits": False,
            "reward_api_url": "localhost",
            "reward_api_port": 8001,
            "use_wandb": True,
            "wandb_project": "",
            "enable_stage2_training": True,
            "stage2_data_dir": f"{base_dir}/stage2_training_data",
            "stage2_export_path": f"{base_dir}/stage2_checkpoints",
            "stage2_epochs": 2,
            "stage2_num_samples": 4,
            "stage2_training_num": 3200000,
            "lora_checkpoint_path": args.lora_checkpoint_path,
        },
        "dataset": {
            "dataset_type": "",
            "n_sample": 3200000
        },
        "paths": {
            "cache_file": args.cache_file,
            "data_path": args.data_path,
            "save_dir": f"{base_dir}/stage1_checkpoints",
            "test_data_path": args.test_data_path,
            "save_path": f"{base_dir}/eval_results/eval_{{TIMESTAMP}}.pkl"
        }
    }

    json_formatted_str = json.dumps(config, indent=2)
    print(json_formatted_str)

    main(config)

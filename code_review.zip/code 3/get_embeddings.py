import json
import pickle
import nltk
import torch
from vllm import LLM

try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('tokenizers/punkt_tab')
except Exception as e:
    print("Punkt tokenizer not found. Downloading now...")
    nltk.download('punkt_tab')
    nltk.download('punkt')

def read_jsonl(file_path):
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            data.append(json.loads(line))
    return data

def get_embeddings(texts, model, batch_size=16):
    all_embeddings = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i+batch_size]
        outputs = model.embed(batch)
        embeddings = torch.tensor([o.outputs.embedding for o in outputs])
        all_embeddings.append(embeddings)
    all_embeddings = torch.cat(all_embeddings, dim=0)
    return all_embeddings.cpu().numpy()

def enc_articles(data_path, output_path, model, batch_size=16):
    data = json.load(open(data_path, 'r', encoding='utf-8'))
    try:
        sent_embeddings = pickle.load(open(output_path, 'rb'))
    except:
        sent_embeddings = {}
    for item in data:
        doc_id = item["docid"]
        if doc_id in sent_embeddings:
            continue
        title = item["title"]
        content = item["content"]
        pdate = item["date"]
        full_text = "Title: " + title + ". Date: " + pdate + ". " + content
        sentences = nltk.sent_tokenize(full_text)
        all_texts = [full_text] + sentences
        embeddings = get_embeddings(all_texts, model, batch_size=batch_size)
        sent_embeddings[doc_id] = {}
        sent_embeddings[doc_id]["full_text_embedding"] = embeddings[0]
        sent_embeddings[doc_id]["sentence_embeddings"] = embeddings[1:]
        sent_embeddings[doc_id]["sentences"] = sentences
        sent_embeddings[doc_id]["label"] = item["label"]
        sent_embeddings[doc_id]["published_date"] = item["date"]
        with open(output_path, 'wb') as f:
            pickle.dump(sent_embeddings, f)
    return sent_embeddings

if __name__ == "__main__":
    import os
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--train_path", type=str, required=True,
                        help="Path to training data .json file")
    parser.add_argument("--test_path", type=str, required=True,
                        help="Path to test data .json file")
    parser.add_argument("--output_path", type=str, required=True,
                        help="Path to output .pkl file")
    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output_path), exist_ok=True)

    model = LLM(model="Qwen/Qwen3-Embedding-8B", task="embed")

    print(f"Encoding train data: {args.train_path}")
    enc_articles(args.train_path, args.output_path, model, batch_size=128)

    print(f"Encoding test data: {args.test_path}")
    enc_articles(args.test_path, args.output_path, model, batch_size=128)

    print(f"Done. Saved to {args.output_path}")
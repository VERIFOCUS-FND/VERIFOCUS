# Instructions

> **Review-only notice.** This codebase is currently provided solely for peer review of the associated manuscript. The manuscript-specific code, scripts, configuration files, and documentation in this repository are confidential and must not be redistributed, mirrored, publicly posted, or used outside the review process without explicit permission from the authors. Third-party libraries and bundled external components remain governed by their own licenses.


---

## Overview


**VERIFOCUS** decomposes the problem into two stages:

1. **SELECTOR** — a lightweight PPO-trained policy that reads an article sentence by sentence and identifies candidate *falsity-indicative* sentences without any sentence-level annotation.
2. **VERIFIER** — an 8B search-augmented LLM fine-tuned with GRPO that performs interleaved reasoning and BM25 evidence retrieval over the selected sentences to predict article veracity.

The two agents are trained with a hierarchical RL (HRL) procedure: the VERIFIER's article-level prediction provides trajectory-level reward feedback for the SELECTOR, while SELECTOR-produced cue subsets drive VERIFIER adaptation. The agents are updated in alternating cycles — SELECTOR (PPO) then VERIFIER (GRPO) — while keeping the other agent frozen.

```
Article (full text)
      │
      ▼
┌────────────────────────┐
│   SELECTOR             │  PPO · 3-layer MLP · binary Select/Skip
│   a2c_ppo_acktr/       │  State: sentence emb + context emb + position
└────────────────────────┘
      │  selected sentences S*
      ▼
┌────────────────────────┐
│   VERIFIER             │  GRPO · 8B LLM + LoRA
│   SkyRL/               │  Search-R1 style: <think> → <search> → <answer>
└────────────────────────┘
      │
      ▼
  Prediction: real / fake
```


## Installation

Dependencies are declared in `pyproject.toml` and `SkyRL/skyrl-train/pyproject.toml`.

### VERIFIER dependencies
```
cd SkyRL/skyrl-train && uv sync --extra vllm && cd ../..
```

#### SELECTOR dependencies
```
uv pip install rank-bm25 psutil pandas pyarrow nltk
```

---

## Data Preparation

### Data Format

Each article in `train.json` / `test.json` should have the following fields:

```json
{
  "docid": "unique-article-id",
  "title": "Article headline",
  "content": "Full article body text.",
  "date": "2024-01-01",
  "label": 1
}
```

`label`: `1` = real, `0` = fake.

### Step 1 — Precompute Embeddings

The SELECTOR uses Qwen3-Embedding-8B embeddings for sentences and documents, precomputed offline to reduce training overhead.

```bash
python get_embeddings.py \
    --train_path data/train.json \
    --test_path data/test.json \
    --output_path data/embeddings.pkl
```

This writes a `.pkl` file mapping each `docid` to its sentence embeddings, document embedding, tokenized sentences, label, and date.

### Step 2 — Build BM25 Retrieval Index

The VERIFIER retrieves evidence from a per-article BM25 corpus (top-10 passages). Build the index from a JSONL corpus file:

```bash
python corpus/build_bm25_index.py \
    --corpus_path data/corpus.jsonl \
    --output_dir data/bm25_index
```

The corpus JSONL should have one document per line with fields `id` (or `docid`), `title`, and `text` (or `contents`). The script outputs a chunked passage store and serialized BM25 index.

### Step 3 — Start the BM25 Retrieval Server

The VERIFIER queries a BM25 retrieval server at `http://127.0.0.1:8000/retrieve` during training (configured via `training.environment.search.search_url` in `stage2_config.json`).

```bash
python SkyRL/skyrl-train/examples/search/retriever/bm25_retrieval_server.py \
    --index_dir data/bm25_index \
    --topk 10 \
    --port 8000
```

This loads the index built in Step 2 and exposes a synchronous `/retrieve` endpoint. The optional `doc_id` field restricts search to passages from a single article (within-document BM25).

---

## Training

VERIFOCUS is trained with alternating HRL cycles. In each cycle, the VERIFIER is frozen while the SELECTOR is updated with PPO, then the SELECTOR is frozen while the VERIFIER is updated with GRPO.


### Launch Query_focused Summarizer

```bash
SkyRL/skyrl-train/examples/search/start_query_focused_summarizer.sh
```

### Training

```bash
uv python main.py \
    --data_path data/train.json \
    --test_data_path data/test.json \
    --cache_file data/embeddings.pkl \
    --base_dir ./outputs \
    --lora_checkpoint_path /path/to/warmup_lora_checkpoint
```

Set `WANDB_API_KEY` as an environment variable before running.

The configuration can be set in `main.py` and `stage2_config.json`; set GPU layout and wandb project name before training.


---

## Acknowledgements

The codebase is built on [SkyRL](https://github.com/NovaSky-AI/SkyRL). Please refer to the original repository for details on the underlying RL framework and installation instructions, and license terms. The SELECTOR implementation adapts components from [pytorch-a2c-ppo-acktr-gail](https://github.com/ikostrikov/pytorch-a2c-ppo-acktr-gail).

"""
Build BM25 index from a JSONL corpus.

Place this script alongside your corpus JSONL file and run:
    python build_bm25_index.py --corpus_path corpus.jsonl --output_dir ./bm25_index

Supported JSONL formats:
  a) Raw format:
       {"docid": "abc123", "title": "...", "content": "...", ...}
  b) Standard retrieval format:
       {"id": "abc123", "title": "...", "text": "..."}
       {"id": "abc123", "title": "...", "contents": "..."}

Outputs (written to --output_dir):
  passages.json   — list of {doc_id, title, passage_idx, text}
  bm25.pkl        — serialized BM25Okapi model over all passages (global search)
  doc_bm25.pkl    — dict[doc_id -> BM25Okapi] for within-doc search (pre-built, no rebuild at query time)
  doc_map.json    — dict[doc_id -> list of global passage indices]
"""

import json
import re
import pickle
import argparse
import os
from typing import List

from rank_bm25 import BM25Okapi


# ---------------------------------------------------------------------------
# JSONL loading & normalization
# ---------------------------------------------------------------------------

def load_jsonl(path: str) -> List[dict]:
    docs = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                docs.append(json.loads(line))
    return docs


def normalize_entry(entry: dict) -> dict:
    # docid = claim ID used for within-doc grouping (e.g. "abc123")
    # result_id = unique per-search-result ID (e.g. "abc123_0")
    docid     = str(entry.get("docid") or entry.get("id") or entry.get("_id") or "")
    result_id = str(entry.get("id") or entry.get("_id") or docid)
    title     = entry.get("title", "")
    # contents (plural) is the field produced by convert_to_jsonl.py
    text      = entry.get("contents") or entry.get("content") or entry.get("text") or ""
    return {"docid": docid, "result_id": result_id, "title": title, "text": text}


# ---------------------------------------------------------------------------
# Passage splitting
# ---------------------------------------------------------------------------

def split_into_passages(text: str, passage_size: int, stride: int) -> List[str]:
    words = text.split()
    if not words:
        return []
    passages, start = [], 0
    while start < len(words):
        passages.append(" ".join(words[start: start + passage_size]))
        if start + passage_size >= len(words):
            break
        start += stride
    return passages


def tokenize(text: str) -> List[str]:
    return re.findall(r"\w+", text.lower())


# ---------------------------------------------------------------------------
# Main build logic
# ---------------------------------------------------------------------------

def build_and_save(corpus_path: str, output_dir: str,
                   passage_size: int, stride: int):
    os.makedirs(output_dir, exist_ok=True)

    raw = load_jsonl(corpus_path)
    print(f"Loaded {len(raw)} raw entries from {corpus_path}")

    passage_records: List[dict] = []
    tokenized_passages: List[List[str]] = []
    doc_map: dict = {}          # doc_id -> [global passage indices]
    doc_tokenized: dict = {}    # doc_id -> [tokenized passages] (for per-doc BM25)
    seen: set = set()

    for entry in raw:
        norm = normalize_entry(entry)
        docid, result_id, title, text = norm["docid"], norm["result_id"], norm["title"], norm["text"]

        if result_id in seen or not text:
            continue
        seen.add(result_id)

        for pidx, chunk in enumerate(split_into_passages(text, passage_size, stride)):
            tokens = tokenize(chunk)
            global_idx = len(passage_records)

            passage_records.append({
                "doc_id":    docid,      # doc ID — used for within-doc grouping
                "result_id": result_id,  # original search result ID (docid_idx) — for provenance
                "title":     title,
                "passage_idx": pidx,
                "text": chunk,
            })
            tokenized_passages.append(tokens)
            doc_map.setdefault(docid, []).append(global_idx)
            doc_tokenized.setdefault(docid, []).append(tokens)

    unique_docs = len(doc_map)
    print(f"  → {unique_docs} unique docs → {len(passage_records)} passages")

    # passages.json
    passages_path = os.path.join(output_dir, "passages.json")
    with open(passages_path, "w", encoding="utf-8") as f:
        json.dump(passage_records, f, ensure_ascii=False, indent=2)
    print(f"Saved passages      → {passages_path}")

    # doc_map.json
    doc_map_path = os.path.join(output_dir, "doc_map.json")
    with open(doc_map_path, "w", encoding="utf-8") as f:
        json.dump(doc_map, f)
    print(f"Saved doc map       → {doc_map_path}")

    # doc_bm25.pkl  (per-doc BM25 indices for within-doc search)
    print(f"Building {unique_docs} per-doc BM25 indices …")
    doc_bm25 = {did: BM25Okapi(toks) for did, toks in doc_tokenized.items()}
    doc_bm25_path = os.path.join(output_dir, "doc_bm25.pkl")
    with open(doc_bm25_path, "wb") as f:
        pickle.dump(doc_bm25, f)
    print(f"Saved per-doc index → {doc_bm25_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build BM25 index from a JSONL corpus.")
    parser.add_argument("--corpus_path", type=str, required=True,
                        help="Path to the input JSONL corpus file.")
    parser.add_argument("--output_dir", type=str, default="./bm25_index",
                        help="Directory to write index artifacts.")
    parser.add_argument("--passage_size", type=int, default=100,
                        help="Number of words per passage chunk.")
    parser.add_argument("--passage_stride", type=int, default=50,
                        help="Stride (words) between consecutive passages.")
    args = parser.parse_args()

    build_and_save(
        corpus_path=args.corpus_path,
        output_dir=args.output_dir,
        passage_size=args.passage_size,
        stride=args.passage_stride,
    )

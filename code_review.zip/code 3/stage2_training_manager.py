#!/usr/bin/env python3
import os
import json
import subprocess
import time
import requests
import psutil
import pandas as pd
import gc
import traceback
from pathlib import Path
from typing import Optional, Dict, List

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


def get_gpu_memory_info() -> Dict:
    """Get detailed GPU memory usage information."""
    gpu_info = {}
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,name,memory.total,memory.used,memory.free,utilization.gpu,utilization.memory",
             "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                parts = [p.strip() for p in line.split(',')]
                if len(parts) >= 7:
                    idx = int(parts[0])
                    gpu_info[idx] = {
                        'name': parts[1],
                        'memory_total_mb': int(parts[2]),
                        'memory_used_mb': int(parts[3]),
                        'memory_free_mb': int(parts[4]),
                        'gpu_util_percent': int(parts[5]) if parts[5] != '[N/A]' else 0,
                        'mem_util_percent': int(parts[6]) if parts[6] != '[N/A]' else 0,
                    }
    except Exception as e:
        gpu_info['error'] = str(e)
    return gpu_info


def get_gpu_processes() -> List[Dict]:
    """Get detailed information about all GPU processes."""
    processes = []
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-compute-apps=pid,gpu_uuid,process_name,used_gpu_memory",
             "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0 and result.stdout.strip():
            for line in result.stdout.strip().split('\n'):
                parts = [p.strip() for p in line.split(',')]
                if len(parts) >= 4:
                    try:
                        processes.append({
                            'pid': int(parts[0]),
                            'gpu_uuid': parts[1],
                            'process_name': parts[2],
                            'used_memory_mb': int(parts[3]) if parts[3] != '[N/A]' else 0,
                        })
                    except ValueError:
                        continue
    except Exception as e:
        processes.append({'error': str(e)})
    return processes


def print_memory_diagnostic(context: str = ""):
    """Print a full memory diagnostic report.

    Args:
        context: Description of the current operation.
    """
    print("\n" + "=" * 80)
    print(f"MEMORY DIAGNOSTIC {'- ' + context if context else ''}")
    print("=" * 80)
    
    # System memory
    print("\nSystem Memory:")
    mem = psutil.virtual_memory()
    print(f"  Total: {mem.total / (1024**3):.1f} GB")
    print(f"  Used:  {mem.used / (1024**3):.1f} GB ({mem.percent}%)")
    print(f"  Free:  {mem.available / (1024**3):.1f} GB")
    
    # GPU memory
    print("\nGPU Memory:")
    gpu_info = get_gpu_memory_info()
    if 'error' in gpu_info:
        print(f"  Error getting GPU info: {gpu_info['error']}")
    else:
        for idx, info in gpu_info.items():
            usage_pct = (info['memory_used_mb'] / info['memory_total_mb'] * 100) if info['memory_total_mb'] > 0 else 0
            status = "RED" if usage_pct > 90 else "YELLOW" if usage_pct > 70 else "GREEN"
            print(f"  GPU {idx} ({info['name']}):")
            print(f"    {status} Memory: {info['memory_used_mb']:,} / {info['memory_total_mb']:,} MB ({usage_pct:.1f}%)")
            print(f"    GPU Util: {info['gpu_util_percent']}%, Mem Util: {info['mem_util_percent']}%")
    
    # GPU processes
    print("\nGPU Processes:")
    processes = get_gpu_processes()
    if not processes:
        print("  No GPU processes running")
    elif 'error' in processes[0]:
        print(f"  Error: {processes[0]['error']}")
    else:
        # Sort by memory usage descending
        processes.sort(key=lambda x: x.get('used_memory_mb', 0), reverse=True)
        for proc in processes[:10]:  # Show top 10
            try:
                # Get process details
                p = psutil.Process(proc['pid'])
                cmdline = ' '.join(p.cmdline())[:60] + '...' if len(' '.join(p.cmdline())) > 60 else ' '.join(p.cmdline())
                print(f"  PID {proc['pid']}: {proc['used_memory_mb']:,} MB - {proc['process_name']}")
                print(f"    Command: {cmdline}")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                print(f"  PID {proc['pid']}: {proc['used_memory_mb']:,} MB - {proc['process_name']}")
    
    # PyTorch memory (if available)
    if HAS_TORCH and torch.cuda.is_available():
        print("\nPyTorch CUDA Memory:")
        for i in range(torch.cuda.device_count()):
            try:
                allocated = torch.cuda.memory_allocated(i) / (1024**3)
                reserved = torch.cuda.memory_reserved(i) / (1024**3)
                max_allocated = torch.cuda.max_memory_allocated(i) / (1024**3)
                print(f"  GPU {i}: Allocated={allocated:.2f}GB, Reserved={reserved:.2f}GB, Max={max_allocated:.2f}GB")
            except Exception as e:
                print(f"  GPU {i}: Error - {e}")
    
    print("=" * 80 + "\n")


def force_cleanup_gpu_memory():
    """Force GPU memory cleanup."""
    print("\nForce GPU Memory Cleanup...")

    # Python garbage collection
    gc.collect()

    # PyTorch memory cleanup
    if HAS_TORCH and torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            try:
                torch.cuda.empty_cache()
                torch.cuda.reset_peak_memory_stats(i)
            except Exception as e:
                print(f"  Warning: Could not clear cache for GPU {i}: {e}")
    
    print("Cleanup completed")


class Stage2TrainingManager:
    """
    Manages Stage 2 training and inference server lifecycle
    """
    
    def __init__(
        self,
        data_dir: str = "./data",
        model_path: str = "Qwen/Qwen3-8B",
        base_export_path: str = "$HOME/skyrl_exports",
        inference_server_host: str = "localhost",
        inference_server_port: int = 8001,
        config_file: str = "stage2_config.json",
        skyrl_project_dir: str = "./SkyRL/skyrl-train"
    ):
        self.data_dir = data_dir
        self.model_path = model_path
        self.base_export_path = os.path.expandvars(base_export_path)
        self.inference_server_host = inference_server_host
        self.inference_server_port = inference_server_port
        self.skyrl_project_dir = skyrl_project_dir  # SkyRL project directory (contains pyproject.toml)
        

        self.config = self._load_config(config_file)
        
        self.inference_server_process = None
        self.inference_server_pid = None  
        self.inference_server_child_pids = set()  
        self.training_process = None
        
        self.training_iteration = 0
        
        self.latest_export_path = None 

        self.state_file = os.path.join(self.base_export_path, "stage2_state.json")
        self.lora_path = None 
        self._load_state()

        # OOM recovery tracking
        self.oom_recovery_attempts = {}
        self.last_successful_config = None
    
    def _load_config(self, config_file: str) -> Dict:
        config_path = os.path.join(os.path.dirname(__file__), config_file)
        
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
            print(f"Loaded configuration from {config_path}")
            print(json.dumps(config, indent=2))
            return config
        else:
            print(f"Config file not found: {config_path}")
            print("Using default hardcoded configuration")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        return {
            "training": {
                "algorithm": {"advantage_estimator": "grpo", "use_kl_loss": True, "kl_loss_coef": 0.001},
                "model": {"lora": {"rank": 32, "alpha": 32}, "mixed_precision": "bf16"},
                "optimizer": {"lr": 5e-6, "max_grad_norm": 0.5, "num_warmup_steps": 10},
                "strategy": {"type": "fsdp2", "colocate_all": True, "policy_fsdp_cpu_offload": False,
                           "ref_fsdp_cpu_offload": True, "policy_num_gpus_per_node": 2, "ref_num_gpus_per_node": 2},
                "generator": {"num_inference_engines": 1, "inference_engine_tensor_parallel_size": 2,
                            "backend": "vllm", "gpu_memory_utilization": 0.9},
                "training_params": {"train_batch_size": 32, "eval_batch_size": 64}
            },
            "inference_server": {
                "generator": {"gpu_memory_utilization": 0.8, "inference_engine_tensor_parallel_size": 1},
                "training_params": {"eval_batch_size": 128}
            },
            "system": {"cuda_visible_devices": "0"}
        }
    
    def _load_state(self):
        os.makedirs(self.base_export_path, exist_ok=True)
        if os.path.exists(self.state_file):
            with open(self.state_file, 'r') as f:
                state = json.load(f)
            self.lora_path = state.get('lora_path', None)
            print(f"Loaded state from {self.state_file}: lora_path={self.lora_path}")
        else:
            self.lora_path = self.config.get('training', {}).get('model', {}).get('lora', {}).get('lora_checkpoint_path', None)
            self._save_state()
            print(f"Initialized state from config: lora_path={self.lora_path}")

    def _save_state(self):
        state = {'lora_path': self.lora_path}
        with open(self.state_file, 'w') as f:
            json.dump(state, f, indent=2)
        print(f"Saved state to {self.state_file}: lora_path={self.lora_path}")

    def save_training_data(self, training_data: List[Dict], val_data: List[Dict], iteration: int) -> tuple:
        save_dir = os.path.join(self.base_export_path, f"iteration_{iteration}")
        os.makedirs(save_dir, exist_ok=True)
        
        data_file = os.path.join(save_dir, "stage2_training_data.parquet")
        
        df = pd.DataFrame(training_data)
        df.to_parquet(data_file, engine='pyarrow', index=False)

        val_data_file = os.path.join(save_dir, "stage2_val_data.parquet")
        
        df_val = pd.DataFrame(val_data)
        df_val.to_parquet(val_data_file, engine='pyarrow', index=False)
    
    def check_inference_server_status(self) -> bool:
        try:
            endpoints = [f"http://{self.inference_server_host}:{self.inference_server_port}/health"]
            
            for endpoint in endpoints:
                try:
                    response = requests.get(endpoint, timeout=2)
                    if response.status_code in [200, 307]:  
                        return True
                except:
                    continue
            
            return False
        except:
            return False
    
    def _collect_child_pids(self, parent_pid: int) -> set:
        """Collect all descendant PIDs of a given process."""
        child_pids = set()
        try:
            parent = psutil.Process(parent_pid)
            for child in parent.children(recursive=True):
                child_pids.add(child.pid)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        return child_pids

    def stop_inference_server(self, timeout: int = 30):
        if self.inference_server_process is None and self.inference_server_pid is not None:
            try:
                self.inference_server_process = psutil.Process(self.inference_server_pid)
            except psutil.NoSuchProcess:
                print(f"Tracked PID {self.inference_server_pid} no longer exists")
                self.inference_server_process = None
        
        if self.inference_server_process is None:
            current_uid = os.getuid()
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'uids']):
                try:
                    cmdline = proc.info.get('cmdline', [])
                    uids = proc.info.get('uids', None)
                    cmdline_str = ' '.join(str(arg) for arg in cmdline) if cmdline else ''

                    if (cmdline
                        and uids and uids.real == current_uid
                        and str(self.inference_server_port) in cmdline_str
                        and 'main_api_server' in cmdline_str):
                        self.inference_server_process = proc
                        self.inference_server_pid = proc.pid
                        print(f"Found manager's inference server by cmdline match (PID: {proc.pid})")
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        
        our_pids = set()
        if self.inference_server_process:
            our_pids.add(self.inference_server_process.pid)
            our_pids.update(self._collect_child_pids(self.inference_server_process.pid))
            our_pids.update(self.inference_server_child_pids)
        
        if self.inference_server_process:
            try:
                pid = self.inference_server_process.pid
                print(f"Sending SIGTERM to inference server process tree (PID: {pid}, {len(our_pids)} processes)...")
                
                # Terminate all child processes first
                parent = psutil.Process(pid)
                children = parent.children(recursive=True)
                for child in children:
                    try:
                        child.terminate()
                    except psutil.NoSuchProcess:
                        pass
                parent.terminate()

                # Wait for graceful exit
                gone, alive = psutil.wait_procs([parent] + children, timeout=timeout)
                if alive:
                    print(f"Timeout: {len(alive)} processes still alive, forcing kill...")
                    for p in alive:
                        try:
                            p.kill()
                        except psutil.NoSuchProcess:
                            pass
                    psutil.wait_procs(alive, timeout=5)
                
                print("Inference server process tree stopped")
                
            except psutil.NoSuchProcess:
                print("Inference server already stopped")
            except Exception as e:
                print(f"Error stopping inference server: {e}")
        else:
            print("No inference server process found (nothing to kill)")
        
        time.sleep(5)
        if not self.check_inference_server_status():
            print("Inference server confirmed stopped")
        else:
            print("Warning: Inference server may still be running on our port")
        
        print("\nCleaning up remaining Ray workers from our process tree...")
        for pid in our_pids:
            try:
                p = psutil.Process(pid)
                if 'ray' in p.name().lower() or any('ray' in str(arg).lower() for arg in (p.cmdline() or [])):
                    print(f"  Killing residual Ray worker PID {pid}")
                    p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        print("\nStopping Ray cluster...")
        subprocess.run(["ray", "stop", "--force"], check=False, capture_output=True)
        time.sleep(10)
        
        print("\nChecking GPU status...")
        try:
            result = subprocess.run(
                ["nvidia-smi"],
                capture_output=True,
                text=True,
                timeout=10
            )
            print(result.stdout)
            
            print("\nChecking for remaining vLLM processes...")
            gpu_procs = subprocess.run(
                ["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if gpu_procs.stdout.strip():
                for line in gpu_procs.stdout.strip().split('\n'):
                    if not ('vllm' in line.lower() or 'ray::' in line.lower()):
                        continue

                    try:
                        line_pid = int(line.strip().split(',')[0].strip())
                    except (ValueError, IndexError):
                        line_pid = None
                    
                    if line_pid and line_pid in our_pids:
                        print(f"  [MANAGER/RESIDUAL]      {line}  <-- residual from this manager, may need manual cleanup")
                    else:
                        print(f"  [INDEPENDENT SERVICE]   {line}  <-- independent service, will not be touched by manager")
            else:
                print("No GPU processes detected.")
                
        except subprocess.TimeoutExpired:
            print("Warning: nvidia-smi timeout")
        except FileNotFoundError:
            print("Warning: nvidia-smi not found")
        except Exception as e:
            print(f"Warning: Could not check GPU status: {e}")
        
        self.inference_server_process = None
        self.inference_server_pid = None
        self.inference_server_child_pids = set()
    
    def run_stage2_training(
        self,
        iteration: int,
        epochs: int = 3,
        additional_args: Optional[List[str]] = None,
        train_data_path: Optional[str] = None,
        val_data_path: Optional[str] = None,
        run_name: Optional[str] = None,
        group_name: Optional[str] = None
    ) -> bool:
        
        self.training_iteration = iteration
        
        import datetime
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        run_name = run_name or f"stage2_iter{iteration}_{timestamp}"
        group_name = group_name or f"stage2_training_iterations"
        ckpt_path = os.path.join(self.base_export_path, run_name, "checkpoints")
        export_path = os.path.join(self.base_export_path, run_name, "exports")

        if train_data_path is None:
            saved_data_dir = os.path.join(self.base_export_path, f"iteration_{iteration}")
            train_data_path = os.path.join(saved_data_dir, "stage2_training_data.parquet")

        if val_data_path is None:
            saved_data_dir = os.path.join(self.base_export_path, f"iteration_{iteration}")
            val_data_path = os.path.join(saved_data_dir, "stage2_val_data.parquet")

        lora_path = self.lora_path
        if lora_path:
            print(f"Using LoRA weights from state: {lora_path}")
        else:
            print(f"No LoRA checkpoint in state, will train from base model")
        
        env = os.environ.copy()
        wandb_key = self.config.get('system', {}).get('wandb_api_key') or os.environ.get('WANDB_API_KEY', '')
        cuda_devices = self.config.get('system', {}).get('cuda_visible_devices', '5,7')
        env.update({
            'WANDB_API_KEY': wandb_key,
            'CUDA_LAUNCH_BLOCKING': '1',
            'HYDRA_FULL_ERROR': '1',
            'CUDA_VISIBLE_DEVICES': cuda_devices,
        })
        
        cfg = self.config.get('training', {})

        cmd = [
            "uv", "run", "--isolated", "--extra", "vllm",
            "-m", "skyrl_train.entrypoints.main_base",

            f"data.train_data=['{train_data_path}']",
            f"data.val_data=['{val_data_path}']",
            
            f"trainer.algorithm.advantage_estimator={cfg.get('algorithm', {}).get('advantage_estimator', 'grpo')}",
            f"trainer.algorithm.use_kl_loss={'true' if cfg.get('algorithm', {}).get('use_kl_loss', True) else 'false'}",
            f"trainer.algorithm.kl_loss_coef={cfg.get('algorithm', {}).get('kl_loss_coef', 0.001)}",
            
            f"trainer.policy.model.path={self.model_path}",
            f"trainer.policy.model.lora.rank={cfg.get('model', {}).get('lora', {}).get('rank', 32)}",
            f"trainer.policy.model.lora.alpha={cfg.get('model', {}).get('lora', {}).get('alpha', 32)}",
            f"+trainer.policy.mixed_precision={cfg.get('model', {}).get('mixed_precision', 'bf16')}",
            
            f"trainer.policy.optimizer_config.lr={cfg.get('optimizer', {}).get('lr', 5e-6)}",
            f"trainer.policy.optimizer_config.max_grad_norm={cfg.get('optimizer', {}).get('max_grad_norm', 0.5)}",
            f"trainer.policy.optimizer_config.num_warmup_steps={cfg.get('optimizer', {}).get('num_warmup_steps', 10)}",
            
            f"trainer.strategy={cfg.get('strategy', {}).get('type', 'fsdp2')}",
            f"trainer.placement.colocate_all={'true' if cfg.get('strategy', {}).get('colocate_all', True) else 'false'}",
            f"trainer.policy.fsdp_config.cpu_offload={'true' if cfg.get('strategy', {}).get('policy_fsdp_cpu_offload', False) else 'false'}",
            f"trainer.ref.fsdp_config.cpu_offload={'true' if cfg.get('strategy', {}).get('ref_fsdp_cpu_offload', True) else 'false'}",
            f"trainer.placement.policy_num_gpus_per_node={cfg.get('strategy', {}).get('policy_num_gpus_per_node', 2)}",
            f"trainer.placement.ref_num_gpus_per_node={cfg.get('strategy', {}).get('ref_num_gpus_per_node', 2)}",
            
            f"generator.num_inference_engines={cfg.get('generator', {}).get('num_inference_engines', 1)}",
            f"generator.inference_engine_tensor_parallel_size={cfg.get('generator', {}).get('inference_engine_tensor_parallel_size', 2)}",
            f"generator.backend={cfg.get('generator', {}).get('backend', 'vllm')}",
            f"generator.enable_prefix_caching={'true' if cfg.get('generator', {}).get('enable_prefix_caching', False) else 'false'}",
            f"generator.run_engines_locally={'true' if cfg.get('generator', {}).get('run_engines_locally', True) else 'false'}",
            f"generator.weight_sync_backend={cfg.get('generator', {}).get('weight_sync_backend', 'nccl')}",
            f"generator.gpu_memory_utilization={cfg.get('generator', {}).get('gpu_memory_utilization', 0.9)}",
            
            f"trainer.epochs={epochs}",
            f"trainer.update_epochs_per_batch={cfg.get('training_params', {}).get('update_epochs_per_batch', 1)}",
            f"trainer.train_batch_size={cfg.get('training_params', {}).get('train_batch_size', 32)}",
            f"trainer.policy_mini_batch_size={cfg.get('training_params', {}).get('policy_mini_batch_size', 8)}",
            f"trainer.micro_forward_batch_size_per_gpu={cfg.get('training_params', {}).get('micro_forward_batch_size_per_gpu', 2)}",
            f"trainer.micro_train_batch_size_per_gpu={cfg.get('training_params', {}).get('micro_train_batch_size_per_gpu', 2)}",
            f"trainer.max_prompt_length={cfg.get('training_params', {}).get('max_prompt_length', 2048)}",
            
            f"environment.env_class={cfg.get('environment', {}).get('env_class', 'search')}",
            f"environment.skyrl_gym.max_env_workers={cfg.get('environment', {}).get('max_env_workers', 16)}",
            f"environment.skyrl_gym.search.log_requests={'true' if cfg.get('environment', {}).get('search', {}).get('log_requests', False) else 'false'}",
            f"environment.skyrl_gym.search.search_url={cfg.get('environment', {}).get('search', {}).get('search_url', 'http://127.0.0.1:9000/retrieve')}",
            f"environment.skyrl_gym.search.topk={cfg.get('environment', {}).get('search', {}).get('topk', 3)}",
            
            f"generator.max_input_length={cfg.get('generator', {}).get('max_input_length', 8192)}",
            f"generator.sampling_params.max_generate_length={cfg.get('generator', {}).get('sampling_params', {}).get('max_generate_length', 1000)}",
            f"generator.async_engine={'true' if cfg.get('generator', {}).get('async_engine', True) else 'false'}",
            f"generator.batched={'true' if cfg.get('generator', {}).get('batched', False) else 'false'}",
            f"generator.use_conversation_multi_turn={'true' if cfg.get('generator', {}).get('use_conversation_multi_turn', False) else 'false'}",
            f"generator.n_samples_per_prompt={cfg.get('generator', {}).get('n_samples_per_prompt', 5)}",
            f"generator.max_turns={cfg.get('generator', {}).get('max_turns', 4)}",
            f"generator.sampling_params.temperature={cfg.get('generator', {}).get('sampling_params', {}).get('temperature', 1.0)}",
            f"generator.sampling_params.top_p={cfg.get('generator', {}).get('sampling_params', {}).get('top_p', 1.0)}",
            f'generator.sampling_params.stop={json.dumps(cfg.get("generator", {}).get("sampling_params", {}).get("stop", ["</search>", "</answer>"]))}',
            f"generator.eval_sampling_params.temperature={cfg.get('generator', {}).get('eval_sampling_params', {}).get('temperature', 0)}",
            f'generator.eval_sampling_params.stop={json.dumps(cfg.get("generator", {}).get("eval_sampling_params", {}).get("stop", ["</search>", "</answer>"]))}',
            
            f"trainer.logger={cfg.get('logging', {}).get('logger', 'wandb')}",
            f"trainer.project_name={cfg.get('logging', {}).get('project_name', 'skyrl-search-training')}",
            f"+trainer.experiment_name={group_name}",
            f"trainer.run_name={run_name}",
            f"+trainer.tags=['stage2','iter{iteration}']",
            
            f"trainer.max_ckpts_to_keep={cfg.get('checkpointing', {}).get('max_ckpts_to_keep', 2)}",
            f"+trainer.save_strategy={cfg.get('checkpointing', {}).get('save_strategy', 'epoch')}",
            f"trainer.resume_mode={cfg.get('checkpointing', {}).get('resume_mode', 'latest')}",
            f"trainer.ckpt_path={ckpt_path}",
            f"trainer.ckpt_interval={cfg.get('checkpointing', {}).get('ckpt_interval', 10000)}",
            f"trainer.hf_save_interval={cfg.get('checkpointing', {}).get('hf_save_interval', 1)}",
            f"trainer.export_path={export_path}",
            
            f"trainer.eval_before_train={'true' if cfg.get('evaluation', {}).get('eval_before_train', False) else 'false'}",
            f"trainer.eval_interval={cfg.get('evaluation', {}).get('eval_interval', 1)}",
            f"trainer.eval_batch_size={cfg.get('training_params', {}).get('eval_batch_size', 64)}",
        ]

        if lora_path:
            cmd.extend([
                f"+trainer.policy.model.lora.lora_checkpoint_path={lora_path}",
                "+generator.enable_lora=true",
            ])
            print(f"Added LoRA resume parameter: {lora_path}")

        if additional_args:
            cmd.extend(additional_args)

        print(f"Training command: {' '.join(cmd[:])}")
        print(f"Working directory: {self.skyrl_project_dir}")

        print_memory_diagnostic("Before Training")
        force_cleanup_gpu_memory()
        
        try:
            result = subprocess.run(
                cmd,
                env=env,
                cwd=self.skyrl_project_dir,
                check=True,
                capture_output=False,
                text=True
            )

            print("\n" + "=" * 80)
            print("Stage 2 Training Completed Successfully!")
            print("=" * 80)

            self.latest_export_path = export_path
            new_export_dirs = list(Path(export_path).glob("global_step_*/policy"))
            if new_export_dirs:
                new_export_dirs_sorted = sorted(new_export_dirs, key=lambda p: int(p.parent.name.split('_')[-1]))
                self.lora_path = str(new_export_dirs_sorted[-1])
                self._save_state()
                print(f"\nUpdated lora_path to: {self.lora_path}")
            else:
                print(f"\nWarning: No global_step_*/policy found in {export_path}, lora_path unchanged")
            
            import shutil
            if os.path.exists(ckpt_path):
                shutil.rmtree(ckpt_path)

            self.last_successful_config = self.config.copy()
            retry_key = f"iter_{iteration}"
            self.oom_recovery_attempts.pop(retry_key, None)

            print_memory_diagnostic("After Training Success")

            # Ray workers spawned by the training subprocess should exit with it.

            print("\nChecking GPU status after training...")
            try:
                result = subprocess.run(
                    ["nvidia-smi"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                print(result.stdout)
                
                print("\nChecking for remaining vLLM processes...")
                gpu_procs = subprocess.run(
                    ["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if gpu_procs.stdout.strip():
                    for line in gpu_procs.stdout.strip().split('\n'):
                        if 'vllm' in line.lower() or 'ray::' in line.lower():
                            print(f"  [INFO] {line}")
                    print("(These may be external vLLM services; not killing them.)")
                else:
                    print("No GPU processes detected.")
                    
            except subprocess.TimeoutExpired:
                print("Warning: nvidia-smi timeout")
            except FileNotFoundError:
                print("Warning: nvidia-smi not found")
            except Exception as e:
                print(f"Warning: Could not check GPU status: {e}")

            return True, val_data_path
            
        except subprocess.CalledProcessError as e:
            print(f"\nStage 2 Training Failed with exit code {e.returncode}")
            print_memory_diagnostic("Post-Training Failure")
            
            force_cleanup_gpu_memory()
        
            return False

        except Exception as e:
            print(f"\nStage 2 Training Error: {e}")

            traceback.print_exc()
            print_memory_diagnostic("Post-Training Error")
            force_cleanup_gpu_memory()

            return False

    def start_inference_server(
        self,
        model_path: Optional[str] = None,
        lora_path: Optional[str] = None,
        val_data_path: Optional[str] = None,
        wait_for_ready: bool = True,
        max_wait: int = 360
    ) -> bool:

        if model_path is None:
            model_path = self.model_path

        if lora_path is None:
            lora_path = self.lora_path
            if lora_path:
                print(f"Using LoRA weights from state: {lora_path}")
            else:
                print(f"No LoRA checkpoint in state, will use base model only")
        
        cfg = self.config.get('inference_server', {})
        sys_cfg = self.config.get('system', {})
        
        env = os.environ.copy()
        wandb_key = sys_cfg.get('wandb_api_key') or os.environ.get('WANDB_API_KEY', '')
        cuda_devices = sys_cfg.get('cuda_visible_devices', '0')
        env.update({
            'WANDB_API_KEY': wandb_key,
            'WANDB_MODE': 'online',
            'CUDA_LAUNCH_BLOCKING': '1',
            'HYDRA_FULL_ERROR': '1',
            'CUDA_VISIBLE_DEVICES': cuda_devices,
        })

        tmp_val_data_path = val_data_path if val_data_path else f"{self.data_dir}/{cfg.get('data', {}).get('val_data', 'validation_demo.parquet')}"
        cmd = [
            "uv", "run",  "--isolated", "--extra", "vllm",
            "-m", "skyrl_train.entrypoints.main_api_server",
            
            f"data.val_data=['{tmp_val_data_path}']",
            
            f"trainer.policy.model.path={model_path}",
            f"trainer.policy.model.lora.rank={cfg.get('model', {}).get('lora', {}).get('rank', 32)}",
            f"trainer.policy.model.lora.alpha={cfg.get('model', {}).get('lora', {}).get('alpha', 32)}",
            
            f"trainer.placement.colocate_all={'true' if cfg.get('placement', {}).get('colocate_all', False) else 'false'}",
            
            f"generator.backend={cfg.get('generator', {}).get('backend', 'vllm')}",
            f"generator.num_inference_engines={cfg.get('generator', {}).get('num_inference_engines', 1)}",
            f"generator.inference_engine_tensor_parallel_size={cfg.get('generator', {}).get('inference_engine_tensor_parallel_size', 1)}",
            f"generator.gpu_memory_utilization={cfg.get('generator', {}).get('gpu_memory_utilization', 0.8)}",
            
            f"trainer.max_prompt_length={cfg.get('training_params', {}).get('max_prompt_length', 8192)}",
            f"generator.max_input_length={cfg.get('generator', {}).get('max_input_length', 16384)}",
            f"generator.max_turns={cfg.get('generator', {}).get('max_turns', 4)}",
            f"generator.sampling_params.max_generate_length={cfg.get('generator', {}).get('sampling_params', {}).get('max_generate_length', 500)}",
            f"generator.eval_sampling_params.max_generate_length={cfg.get('generator', {}).get('eval_sampling_params', {}).get('max_generate_length', 500)}",
            
            f"generator.sampling_params.temperature={cfg.get('generator', {}).get('sampling_params', {}).get('temperature', 0)}",
            f"generator.eval_sampling_params.temperature={cfg.get('generator', {}).get('eval_sampling_params', {}).get('temperature', 0)}",
            f'generator.eval_sampling_params.stop={json.dumps(cfg.get("generator", {}).get("eval_sampling_params", {}).get("stop", ["</search>", "</answer>"]))}',
            
            f"environment.env_class={cfg.get('environment', {}).get('env_class', 'search')}",
            f"environment.skyrl_gym.max_env_workers={cfg.get('environment', {}).get('max_env_workers', 16)}",
            f"environment.skyrl_gym.search.log_requests={'true' if cfg.get('environment', {}).get('search', {}).get('log_requests', False) else 'false'}",
            f"environment.skyrl_gym.search.search_url={cfg.get('environment', {}).get('search', {}).get('search_url', 'http://127.0.0.1:9000/retrieve')}",
            f"environment.skyrl_gym.search.topk={cfg.get('environment', {}).get('search', {}).get('topk', 10)}",
            
            f"api_server.host={cfg.get('api_server', {}).get('host', self.inference_server_host)}",
            f"api_server.port={cfg.get('api_server', {}).get('port', self.inference_server_port)}",
            
            f"trainer.eval_batch_size={cfg.get('training_params', {}).get('eval_batch_size', 128)}",
        ]
        
        if lora_path:
            cmd.extend([
                f"trainer.policy.model.lora.lora_sync_path={lora_path}",
                "+generator.enable_lora=true",
            ])
        
        print(f"Starting inference server with command:")
        print(f"  {' '.join(cmd[:5])}... (truncated)")
        print(f"Working directory: {self.skyrl_project_dir}")

        timestamp = time.strftime("%Y%m%d_%H%M%S")
        
        try:
            log_file = open(f"inference_server_{timestamp}.log", "w")
            self.inference_server_process = subprocess.Popen(
                cmd,
                env=env,
                cwd=self.skyrl_project_dir,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                text=True,
                start_new_session=True,
            )
            
            self.inference_server_pid = self.inference_server_process.pid
            self.inference_server_child_pids = set()
            print(f"Inference server started (PID: {self.inference_server_pid})")
            
            if wait_for_ready:
                print(f"Waiting for inference server to be ready (max {max_wait}s)...")
                print("This may take 1-3 minutes for model loading...")
                start_time = time.time()
                last_check = 0
                
                while time.time() - start_time < max_wait:
                    elapsed = time.time() - start_time
                    if int(elapsed) % 5 == 0 and int(elapsed) != last_check:
                        print(f"  ... waiting {int(elapsed)}s / {max_wait}s")
                        last_check = int(elapsed)
                    
                    if self.check_inference_server_status():
                        elapsed = time.time() - start_time
                        print(f"Inference server ready after {elapsed:.1f}s")
                        return True
                    
                    time.sleep(2)
                
                print("Timeout waiting for inference server to be ready")
                return False
            
            return True
            
        except Exception as e:
            print(f"Failed to start inference server: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def perform_stage2_training_cycle(
        self,
        iteration: int,
        epochs: int = 3,
        use_collected_data: bool = False
    ) -> bool:
        
        self.stop_inference_server()
        
        time.sleep(20)  # Wait for server to fully stop

        training_success, val_data_path = self.run_stage2_training(
            iteration=iteration,
            epochs=epochs
        )
        
        server_success = self.start_inference_server(val_data_path=val_data_path,wait_for_ready=True)
        
        if not server_success:
            print("Failed to start inference server with new model")
            return False
        
        return True
    
    def cleanup(self):

        if self.inference_server_process:
            self.stop_inference_server()

        if self.training_process and self.training_process.poll() is None:
            self.training_process.terminate()
            try:
                self.training_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.training_process.kill()

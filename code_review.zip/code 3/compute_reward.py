#!/usr/bin/env python3
import requests
import json
import time
import sys
import re
import random
import wandb
import datetime

DATASET_NAME = ""

def extract_solution(solution_str):

    answer_pattern = r"<answer>(.*?)</answer>"
    match = re.finditer(answer_pattern, solution_str, re.DOTALL)
    matches = list(match)

    if len(matches) < 1:
        return None

    return matches[-1].group(1).strip()

def process_outputs(detailed_results):
    results = detailed_results["per_dataset"][DATASET_NAME]
    processed_results = []

    for result in results:
        try:
            output_response = result["output_response"]
            pred = extract_solution(output_response)
            ground_truth = result["env_extras"]["reward_spec"]["ground_truth"]["target"][0]
            article_id = result["env_extras"]["extra_info"]["index"]

            result["prediction"] = pred
            result["ground_truth"] = ground_truth
            result["output_response"] = output_response
            result["article_id"] = article_id
        except Exception as e:
            print(f"Error processing result: {e}")
            result["prediction"] = None
            result["ground_truth"] = None
            result["output_response"] = None
            result["article_id"] = None

        processed_results.append(result)

    return processed_results

def check_search_server(search_host="127.0.0.1", search_port=8000, verbose=True):
    """
    Check if the search server is running.
    
    Args:
        search_host: Search server host
        search_port: Search server port
        verbose: Whether to print status messages
    
    Returns:
        bool: True if server is running, False otherwise
    """
    search_url = f"http://{search_host}:{search_port}/health"
    if verbose:
        print(f"Checking if search server is running at {search_url}...")
    try:
        response = requests.get(search_url, timeout=5)
        if verbose:
            print(f"Search server is running")
        return True
    except requests.RequestException:
        if verbose:
            print(f"WARNING: Search server may not be running at http://{search_host}:{search_port}")
            print("Make sure to start your search server before running evaluations")
        return False

def check_api_health(base_url, verbose=True):
    """
    Check the API server health endpoint.
    
    Args:
        base_url: Base URL of the API server
        verbose: Whether to print status messages
    
    Returns:
        dict or None: Health response data if successful, None otherwise
    """
    if verbose:
        print("Testing API server health endpoint...")
    try:
        response = requests.get(f"{base_url}/health", timeout=10)
        if verbose:
            print(f"Health check status: {response.status_code}")
            print(f"Health check response: {response.json()}")
        return response.json() if response.status_code == 200 else None
    except requests.RequestException as e:
        if verbose:
            print(f"Health check failed: {e}")
        return None

def get_api_info(base_url, verbose=True):
    """
    Get API server information.
    
    Args:
        base_url: Base URL of the API server
        verbose: Whether to print status messages
    
    Returns:
        dict or None: API info if successful, None otherwise
    """
    if verbose:
        print("Testing info endpoint...")
    try:
        response = requests.get(f"{base_url}/info", timeout=10)
        info = response.json()
        if verbose:
            print(f"Info status: {response.status_code}")
            print(f"Model: {info.get('model', 'N/A')}")
            print(f"Backend: {info.get('backend', 'N/A')}")
            print(f"Engines: {info.get('engines', 'N/A')}")
            print(f"Has eval dataset: {info.get('has_eval_dataset', False)}")
        return info if response.status_code == 200 else None
    except requests.RequestException as e:
        if verbose:
            print(f"Info endpoint failed: {e}")
        return None

def evaluate_custom_data(base_url, custom_data, timeout=12000, verbose=True):
    """
    Evaluate custom data using the API server.
    
    Args:
        base_url: Base URL of the API server
        custom_data: List of custom evaluation data items
        timeout: Request timeout in seconds
        verbose: Whether to print status messages
    
    Returns:
        dict: Dictionary containing:
            - success (bool): Whether evaluation succeeded
            - metrics (dict): Evaluation metrics if successful
            - detailed_results (dict): Detailed results if successful
            - processed_results (list): Processed results with predictions
            - error (str): Error message if failed
    """
    result = {
        "success": False,
        "metrics": None,
        "detailed_results": None,
        "processed_results": None,
        "error": None
    }
    
    try:
        response = requests.post(
            f"{base_url}/evaluate", 
            json={"data": custom_data},
            headers={"Content-Type": "application/json"},
            timeout=timeout
        )
        
        if response.status_code == 200:
            response_data = response.json()
            
            metrics = response_data['metrics']
            detailed_results = response_data['detailed_results']
            
            if verbose:
                
                # Show key metrics
                key_metrics = [
                    'eval/all/avg_score',
                    'eval/all/pass_at_1'
                ]
                # Add dataset-specific metrics dynamically
                for key in metrics.keys():
                    if key.endswith('/avg_score') and key not in key_metrics:
                        key_metrics.append(key)
                
                print("\nKey Metrics from Custom Data:")
                for metric in key_metrics:
                    if metric in metrics:
                        print(f"  {metric}: {metrics[metric]:.4f}")
            
            # Process outputs
            processed_results = process_outputs(detailed_results)
            
            # Add correctness check
            final_results = []
            for res in processed_results:
                assert res["ground_truth"] is not None
                res["is_correct"] = False
                if res["prediction"] is not None:
                    if res["prediction"].lower() == res["ground_truth"].lower():
                        res["is_correct"] = True
                final_results.append(res)
            
            result["success"] = True
            result["metrics"] = metrics
            result["detailed_results"] = detailed_results
            result["processed_results"] = final_results
            
        else:
            error_msg = f"Evaluation failed with status {response.status_code}"
            if verbose:
                print(error_msg)
            try:
                error_detail = response.json()
                result["error"] = error_detail
                if verbose:
                    print(f"Error detail: {error_detail}")
            except:
                result["error"] = response.text
                if verbose:
                    print(f"Error text: {response.text}")
    
    except requests.Timeout:
        result["error"] = "Request timed out"
        if verbose:
            print("Custom data evaluation timed out")
    except requests.RequestException as e:
        result["error"] = str(e)
        if verbose:
            print(f"Custom data evaluation request failed: {e}")

    return result

def create_sample_custom_data_list(data_list, max_prompt_tokens=9120, target_count=None):

    target = target_count if target_count is not None else len(data_list)
    
    all_custom_data = []
    for input_data in data_list:
        split = input_data["split"]
        article_id = input_data["article_id"]
        selected_sentences = input_data["selected_sentences"]
        published_date = input_data["published_date"]
        if isinstance(published_date, datetime.datetime):
            published_date = published_date.strftime("%Y-%m-%d")
        article_text = input_data["article_text"]
        ground_truth = input_data["ground_truth"]
        custom_data = create_sample_custom_data(split, article_id, selected_sentences, published_date, article_text, ground_truth)
        all_custom_data.extend(custom_data)
    return all_custom_data


def create_sample_custom_data(split, article_id, selected_sentences, published_date, article_text, ground_truth):
    """
    Create sample custom evaluation data.
    
    Returns:
        list: Curated custom data in the expected format
    """
    return [
        {"data_source":DATASET_NAME,"prompt":[
            {"content":"You are an expert fact-checker who verifies news articles using a search tool. \n\nHere are instructions:\n1. Read the entire article and the identified suspicious sentences.\n2. Think step by step before calling the tool and after you receive the result of the tool call. Decide what query to call the tool with.\n3. Call the tool with the query you have decided on. If the returned results are empty, revise and retry the query. \n4. Think step by step again after you receive the result of the tool call. If you have the information you need, you can stop here.\n5. Otherwise, come up with new query that combine information from the previous results.\n6. Include your final answer inside <answer> ... </answer>. The answer should be either real or fake. For example, <answer> real </answer> or <answer> fake </answer>.","role":"system"},
            {"content":f"Decide whether a news article is real or fake based on the provided article and the identified suspicious sentences. The title should be treated as part of the article. Now is {published_date}, which is the same date as the publication date of the news. You must conduct reasoning inside <think> and </think> first every time you get new information. After reasoning, if you find you lack some knowledge or you need to access real-time data, you can call a search engine by <search> query </search> and it will return the top searched results between <information> and </information>. You can search as many times as you want. If you find no further external knowledge needed, you can directly provide the answer without detailed illustrations. For example, <answer> real </answer> or <answer> fake </answer>. Question: Is the news real or fake? Article: {article_text} (Published date: {published_date}). Suspicious Sentences: {selected_sentences}","role":"user"}],"ability":"fact-reasoning","env_class":"search","reward_spec":{"ground_truth":{"target":[ground_truth]},"style":"rule"},
            "extra_info":{"index":article_id,"published_date": published_date, "news_article": article_text, "need_tools_kwargs":True,"question":f"Is the news real or fake? Article: {article_text} (Published date: {published_date}). Suspicious Sentences: {selected_sentences}","split":split,"tools_kwargs":{"search":{"create_kwargs":{"data_source":DATASET_NAME,"ground_truth":{"target":[ground_truth]},"question":f"Is the news real or fake? Article: {article_text} (Published date: {published_date}). Suspicious Sentences: {selected_sentences}"}}}},"metadata":None}
    ]


def check_api_status(host="localhost", port=8001, verbose=True):
    """
    Check the overall API server status.
    
    Args:
        verbose: Whether to print status messages
    
    Returns:
        bool: True if all checks pass, False otherwise
    """
    if verbose:
        print("Checking overall API server status...")
    
    
    base_url = f"http://{host}:{port}"
    
    print(f"Testing Inference API Server at {base_url}")
    
    # Check if search server is running
    print("\n0. Checking if server is running...")
    check_search_server()
    
    # Test health endpoint
    print("\n1. Testing API server health endpoint...")
    if not check_api_health(base_url):
        return False
    
    # Test info endpoint
    print("\n2. Testing info endpoint...")
    if not get_api_info(base_url):
        return False
    
    return True

def call_inference_api_with_custom_data(input_data_list, host="localhost", port=8001, iteration=None):
    """
    Call inference API with custom data and optionally log results to wandb.
    
    Args:
        input_data_list: List of input data
        host: API server host
        port: API server port
    
    Returns:
        result: Dictionary with evaluation results
    """
    base_url = f"http://{host}:{port}"
    custom_data = create_sample_custom_data_list(input_data_list)
    result = evaluate_custom_data(base_url, custom_data)

    if result is None or result.get('processed_results') is None:
        print(f"\nEvaluation failed, no results returned. Total custom data: {len(custom_data)}")
        return None
    
    return result
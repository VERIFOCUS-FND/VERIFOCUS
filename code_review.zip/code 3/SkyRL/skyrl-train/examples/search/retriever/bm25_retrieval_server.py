"""
BM25 Retrieval Server

Same task-queue + direct-retrieve interface as gpt_retrieval_server.py,
backed by a pre-built BM25 index (produced by build_bm25_index.py).

Usage:
    python bm25_retrieval_server.py --index_dir /path/to/bm25_index --topk 10
"""

import json
import re
import time
import pickle
import argparse
import uuid
import asyncio
import uvicorn

from datetime import datetime
from enum import Enum
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from rank_bm25 import BM25Okapi


# ---------------------------------------------------------------------------
# Index loading
# ---------------------------------------------------------------------------

def load_index(index_dir: str):
    import os
    bm25 = None
    with open(os.path.join(index_dir, "passages.json"), "r", encoding="utf-8") as f:
        passage_records: List[dict] = json.load(f)

    with open(os.path.join(index_dir, "doc_map.json"), "r", encoding="utf-8") as f:
        doc_map: dict = json.load(f)
    with open(os.path.join(index_dir, "doc_bm25.pkl"), "rb") as f:
        doc_bm25: dict = pickle.load(f)
    print(f"[BM25] Loaded {len(passage_records)} passages across {len(doc_map)} docs.")
    return passage_records, bm25, doc_map, doc_bm25


# ---------------------------------------------------------------------------
# BM25 engine
# ---------------------------------------------------------------------------

def tokenize(text: str) -> List[str]:
    return re.findall(r"\w+", text.lower())


class BM25Engine:
    def __init__(self, passage_records: List[dict], bm25: BM25Okapi,
                 doc_map: dict, doc_bm25: dict, topk: int):
        self.passage_records = passage_records
        self.bm25 = bm25
        self.doc_map = doc_map
        self.doc_bm25 = doc_bm25   # pre-built at index time
        self.default_topk = topk

    def single_search(self, query: str, num: int = None,
                      doc_id: str = None) -> List[dict]:
        """Return a list of {document: {...}} dicts, matching gpt_retrieval_server format."""
        if num is None:
            num = self.default_topk

        query_tokens = tokenize(query)

        if doc_id is not None:
            candidate_idxs = self.doc_map.get(doc_id, [])
            if not candidate_idxs:
                return []
            local_scores = self.doc_bm25[doc_id].get_scores(query_tokens)
            pairs = sorted(zip(local_scores, candidate_idxs), reverse=True)
        else:
            all_scores = self.bm25.get_scores(query_tokens)
            pairs = sorted(
                ((s, i) for i, s in enumerate(all_scores)),
                reverse=True,
            )

        results = []
        for score, idx in pairs[:num]:
            rec = self.passage_records[idx]
            results.append({
                "document": {
                    "contents":    rec["text"],
                    "title":       rec["title"],
                    "doc_id":      rec["doc_id"],
                    "result_id":   rec["result_id"],
                    "passage_idx": rec["passage_idx"],
                },
                "score": float(score),
            })
        return results


# ---------------------------------------------------------------------------
# Task queue  (identical structure to gpt_retrieval_server.py)
# ---------------------------------------------------------------------------

class TaskStatus(str, Enum):
    PENDING    = "pending"
    PROCESSING = "processing"
    COMPLETED  = "completed"
    FAILED     = "failed"


class SearchTask(BaseModel):
    task_id:              str
    inference_request_id: str
    query:                str
    doc_id:               Optional[str] = None
    topk:                 Optional[int] = None
    status:               TaskStatus = TaskStatus.PENDING
    created_at:           datetime
    updated_at:           Optional[datetime] = None
    results:              Optional[List[Dict[str, Any]]] = None
    error_message:        Optional[str] = None


class TaskRequest(BaseModel):
    inference_request_id: str
    query:                str
    doc_id:               Optional[str] = None
    topk:                 Optional[int] = None


class TaskUpdate(BaseModel):
    results: List[Dict[str, Any]]


class TaskResponse(BaseModel):
    task_id:       str
    status:        TaskStatus
    results:       Optional[List[Dict[str, Any]]] = None
    error_message: Optional[str] = None


class TaskQueue:
    def __init__(self):
        self.tasks: Dict[str, SearchTask] = {}

    def create_task(self, inference_request_id: str, query: str,
                    doc_id: Optional[str] = None,
                    topk: Optional[int] = None) -> str:
        task_id = str(uuid.uuid4())
        self.tasks[task_id] = SearchTask(
            task_id=task_id,
            inference_request_id=inference_request_id,
            query=query,
            doc_id=doc_id,
            topk=topk,
            created_at=datetime.utcnow(),
        )
        return task_id

    def get_task(self, task_id: str) -> Optional[SearchTask]:
        return self.tasks.get(task_id)

    def get_pending_tasks(self) -> List[SearchTask]:
        return [t for t in self.tasks.values() if t.status == TaskStatus.PENDING]

    def update_task_status(self, task_id: str, status: TaskStatus,
                           results=None, error_message=None) -> bool:
        if task_id not in self.tasks:
            return False
        task = self.tasks[task_id]
        task.status     = status
        task.updated_at = datetime.utcnow()
        if results       is not None: task.results       = results
        if error_message is not None: task.error_message = error_message
        return True

    def mark_processing(self, task_id: str) -> bool:
        return self.update_task_status(task_id, TaskStatus.PROCESSING)

    def complete_task(self, task_id: str, results: List[Dict[str, Any]]) -> bool:
        return self.update_task_status(task_id, TaskStatus.COMPLETED, results=results)

    def fail_task(self, task_id: str, error_message: str) -> bool:
        return self.update_task_status(task_id, TaskStatus.FAILED, error_message=error_message)


task_queue = TaskQueue()


# ---------------------------------------------------------------------------
# Task processor
# ---------------------------------------------------------------------------

class TaskProcessor:
    def __init__(self, search_engine: BM25Engine, tq: TaskQueue):
        self.search_engine = search_engine
        self.task_queue    = tq
        self.processing    = False

    async def process_pending_tasks(self):
        if self.processing:
            return
        self.processing = True
        try:
            for task in self.task_queue.get_pending_tasks():
                try:
                    self.task_queue.mark_processing(task.task_id)
                    results = self.search_engine.single_search(
                        query=task.query,
                        num=task.topk,
                        doc_id=task.doc_id,
                    )
                    self.task_queue.complete_task(task.task_id, results)
                except Exception as e:
                    self.task_queue.fail_task(task.task_id, str(e))
        finally:
            self.processing = False


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(title="BM25 Retrieval Server")

engine:         BM25Engine    # set in __main__
task_processor: TaskProcessor  # set in __main__


class QueryRequest(BaseModel):
    query:         str
    doc_id:        Optional[str] = None
    topk:          Optional[int] = None
    return_scores: bool = False


# --- Task queue routes ---

@app.post("/tasks/process")
async def process_tasks():
    """Trigger processing of all pending tasks."""
    await task_processor.process_pending_tasks()
    return {"status": "processing_complete"}


@app.get("/tasks/stats")
def get_task_stats():
    all_tasks = list(task_queue.tasks.values())
    return {
        "total_tasks": len(all_tasks),
        "pending":     sum(1 for t in all_tasks if t.status == TaskStatus.PENDING),
        "processing":  sum(1 for t in all_tasks if t.status == TaskStatus.PROCESSING),
        "completed":   sum(1 for t in all_tasks if t.status == TaskStatus.COMPLETED),
        "failed":      sum(1 for t in all_tasks if t.status == TaskStatus.FAILED),
    }


@app.post("/tasks", response_model=Dict[str, str])
def create_task(request: TaskRequest):
    """Create a search task and return its task_id."""
    task_id = task_queue.create_task(
        inference_request_id=request.inference_request_id,
        query=request.query,
        doc_id=request.doc_id,
        topk=request.topk,
    )
    return {"task_id": task_id}


@app.get("/tasks/pending", response_model=List[SearchTask])
def get_pending_tasks():
    return task_queue.get_pending_tasks()


@app.put("/tasks/{task_id}/results", response_model=Dict[str, str])
def submit_task_results(task_id: str, update: TaskUpdate):
    task = task_queue.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task.status not in (TaskStatus.PENDING, TaskStatus.PROCESSING):
        raise HTTPException(status_code=400, detail=f"Task is already {task.status}")
    if not task_queue.complete_task(task_id, update.results):
        raise HTTPException(status_code=500, detail="Failed to update task")
    return {"status": "success"}


@app.get("/tasks/{task_id}/status", response_model=TaskResponse)
def get_task_status(task_id: str):
    task = task_queue.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return TaskResponse(
        task_id=task.task_id,
        status=task.status,
        results=task.results,
        error_message=task.error_message,
    )


@app.put("/tasks/{task_id}/mark-processing")
def mark_task_processing(task_id: str):
    if not task_queue.mark_processing(task_id):
        raise HTTPException(status_code=404, detail="Task not found")
    return {"status": "processing"}


# --- Direct retrieve route ---

@app.post("/retrieve")
def retrieve_endpoint(request: QueryRequest):
    """
    Direct synchronous retrieval.
    Input:  {"query": "...", "doc_id": "abc123", "topk": 5, "return_scores": true}
    Output: {"result": [[{"document": {...}, "score": 1.2}, ...]]}
    """
    num     = request.topk if request.topk else engine.default_topk
    t0 = time.perf_counter()
    results = engine.single_search(query=request.query, num=num, doc_id=request.doc_id)
    print(f"[TIMER] {time.perf_counter()-t0:.4f}s | doc={request.doc_id}")

    if not request.return_scores:
        results = [{"document": r["document"]} for r in results]

    return {"result": [results]}


@app.get("/health")
def health_check():
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Launch BM25 retrieval server.")
    parser.add_argument("--index_dir", type=str, required=True,
                        help="Directory with passages.json, doc_map.json, doc_bm25.pkl "
                             "(produced by build_bm25_index.py).")
    parser.add_argument("--topk", type=int, default=5,
                        help="Default number of passages to return.")
    parser.add_argument("--host", type=str, default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    passage_records, bm25, doc_map, doc_bm25 = load_index(args.index_dir)
    engine         = BM25Engine(passage_records, bm25, doc_map, doc_bm25, topk=args.topk)
    task_processor = TaskProcessor(engine, task_queue)

    uvicorn.run(app, host=args.host, port=args.port)

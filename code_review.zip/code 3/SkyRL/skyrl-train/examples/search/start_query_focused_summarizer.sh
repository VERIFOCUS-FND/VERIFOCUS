#!/bin/bash
CUDA_VISIBLE_DEVICES= uv run --extra vllm vllm serve Qwen/Qwen3-8B --port 6000 --reasoning-parser qwen3
import json
import torch
from datetime import datetime
from tqdm import tqdm
from typing import Dict, List, Any
from pathlib import Path
from loguru import logger

from skyrl_train.utils import Timer

from skyrl_train.generators.utils import (
    concatenate_generator_outputs,
    get_metrics_from_generator_output,
    prepare_generator_input,
)
from skyrl_train.generators.base import (
    GeneratorOutput,
    GeneratorInterface,
)
from skyrl_train.utils.trainer_utils import (
    calculate_per_dataset_metrics,
    dump_per_dataset_eval_results,
    validate_generator_output,
)
from skyrl_train.inference_engines.utils import get_sampling_params_for_backend

from omegaconf import DictConfig
from torchdata.stateful_dataloader import StatefulDataLoader
from transformers import AutoTokenizer
import json


def dump_per_dataset_eval_results_json(
    dump_dir_path: Path,
    tokenizer: AutoTokenizer,
    concat_generator_outputs: GeneratorOutput,
    concat_data_sources: List[str],
    concat_all_envs: List[str],
    concat_env_extras: List[Dict[str, Any]],
    eval_metrics: Dict[str, float],
) -> Dict[str, Any]:
    """Return evaluation results per dataset and overall aggregated results as a dictionary."""

    # Prepare common data
    input_prompts = [tokenizer.decode(prompt) for prompt in concat_generator_outputs["prompt_token_ids"]]
    output_responses = [tokenizer.decode(response) for response in concat_generator_outputs["response_ids"]]

    # Group indices by data source
    data_source_indices = {}
    for i, data_source in enumerate(concat_data_sources):
        if data_source is None:
            data_source = "unknown"
        if data_source not in data_source_indices:
            data_source_indices[data_source] = []
        data_source_indices[data_source].append(i)

    # Build per-dataset results
    results = {"per_dataset": {}, "aggregated_metrics": eval_metrics}
    
    for data_source, indices in data_source_indices.items():
        results["per_dataset"][data_source] = []
        for i in indices:
            entry = {
                "input_prompt": input_prompts[i],
                "output_response": output_responses[i],
                "score": concat_generator_outputs["rewards"][i],
                "stop_reason": concat_generator_outputs.get("stop_reasons", [None] * len(input_prompts))[i],
                "env_class": concat_all_envs[i],
                "env_extras": concat_env_extras[i],
                "data_source": data_source,
            }
            results["per_dataset"][data_source].append(entry)

    return results




@torch.no_grad()
async def evaluate(
    eval_dataloader: StatefulDataLoader,
    generator: GeneratorInterface,
    cfg: DictConfig,
    global_step: int | None,
    tokenizer: AutoTokenizer,
) -> Dict[str, float]:
    """Runs generation and evaluation of trajectories.

    Args:
        eval_dataloader (StatefulDataLoader): dataloader of the eval dataset
        generator (GeneratorInterface): generator to use
        cfg (DictConfig): config
        global_step (int | None): current global step, or
            `None` to indicate a non-training context (e.g., eval-only)
        tokenizer (AutoTokenizer): tokenizer to use

    Returns:
        Dict[str, float]: evaluation metrics
    """

    # 1. Get all generator outputs
    generator_outputs: List[GeneratorOutput] = []
    concat_all_envs: List[str] = []
    concat_env_extras: List[Dict[str, Any]] = []
    concat_uids: List[str] = []
    sampling_params = cfg.generator.eval_sampling_params
    pbar = tqdm(total=len(eval_dataloader), initial=0, desc="Evaluation Progress")
    for _, prompts in enumerate(eval_dataloader):
        pbar.update(1)
        generator_input, uids = prepare_generator_input(
            prompts,
            cfg.generator.eval_n_samples_per_prompt,
            get_sampling_params_for_backend(cfg.generator.backend, sampling_params),
            cfg.environment.env_class,
            "eval",
            global_step,
        )
        generator_output: GeneratorOutput = await generator.generate(generator_input)
        validate_generator_output(len(generator_input["prompts"]), generator_output)
        generator_outputs.append(generator_output)
        concat_all_envs.extend(generator_input["env_classes"])
        concat_env_extras.extend(generator_input["env_extras"])
        concat_uids.extend(uids)
    concat_generator_outputs: GeneratorOutput = concatenate_generator_outputs(generator_outputs)

    # Extract data_sources from env_extras
    concat_data_sources = [env_extra.get("data_source") for env_extra in concat_env_extras]
    vis = tokenizer.decode(generator_output["response_ids"][0])
    logger.info(f"Eval output example: {vis}")

    # 2. Group data by data source and calculate per-dataset metrics
    eval_metrics = calculate_per_dataset_metrics(
        concat_generator_outputs, concat_uids, concat_data_sources, cfg.generator.eval_n_samples_per_prompt
    )

    # 3. Calculate overall metrics across all datasets
    overall_avg_score, overall_pass_at_n = get_metrics_from_generator_output(concat_generator_outputs, concat_uids)
    eval_metrics.update(
        {
            "eval/all/avg_score": overall_avg_score,
            f"eval/all/pass_at_{cfg.generator.eval_n_samples_per_prompt}": overall_pass_at_n,
        }
    )

    # 4. Prepare dumping data
    with Timer("dump_eval_results"):
        data_save_dir = (
            Path(cfg.trainer.export_path)
            / "dumped_evals"
            / ("eval_only" if global_step is None else f"global_step_{global_step}_evals")
        )
        data_save_dir.mkdir(parents=True, exist_ok=True)
        
        # Create a clean copy of eval_metrics for aggregated_metrics (avoid circular reference)
        clean_eval_metrics = {k: v for k, v in eval_metrics.items() if k != "detailed_results"}
        
        inference_result = dump_per_dataset_eval_results_json(
            data_save_dir,
            tokenizer,
            concat_generator_outputs,
            concat_data_sources,
            concat_all_envs,
            concat_env_extras,
            clean_eval_metrics,
        )

        # Save to JSON file
        json_save_path = data_save_dir / "eval_results.json"
        with open(json_save_path, "w") as json_file:
            # Custom JSON encoder to handle datetime objects
            def datetime_handler(obj):
                if isinstance(obj, datetime):
                    return obj.isoformat()
                raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
            
            json.dump(inference_result, json_file, indent=4, default=datetime_handler)
        logger.info(f"Dumped evaluation results to {json_save_path}")

    # Add detailed results to the returned metrics for API access (avoid circular reference)
    eval_metrics["detailed_results"] = inference_result

    return eval_metrics

"""
Online API server entrypoint for real-time inference.
"""

import asyncio
import os
import signal
import sys
import time
import traceback
import uuid
import threading
from pathlib import Path
from typing import Any, Optional, List, Dict
from datetime import datetime
from dataclasses import dataclass, asdict
from collections import deque

import hydra
import ray
from loguru import logger
from omegaconf import DictConfig
from skyrl_train.dataset import PromptDataset

from skyrl_train.entrypoints.main_base import (
    BasePPOExp,
    config_dir,
    create_ray_wrapped_inference_engines_from_config,
    create_remote_inference_engines_from_config,
)
from skyrl_train.inference_engines.inference_engine_client import InferenceEngineClient
from skyrl_train.inference_engines.inference_engine_client_http_endpoint import serve, wait_for_server_ready
from skyrl_train.utils.utils import validate_generator_cfg, initialize_ray

from skyrl_train.inference import evaluate
from skyrl_train.utils.trainer_utils import build_dataloader

# ============================================================================
# JSON Serialization Helpers
# ============================================================================

def serialize_for_json(obj: Any) -> Any:
    """Recursively convert datetime objects to ISO format strings for JSON serialization."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: serialize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [serialize_for_json(item) for item in obj]
    elif isinstance(obj, (str, int, float, bool, type(None))):
        return obj
    else:
        # For other types, try to convert to string
        return str(obj)

# ============================================================================
# Task Queue Components
# ============================================================================

@dataclass
class SearchTask:
    """Search task data structure"""
    task_id: str
    inference_request_id: str
    query: str
    max_results: int = 30
    search_end_date: str = None
    batch_mode: bool = False
    queries: Optional[List[str]] = None
    created_at: str = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.now().isoformat()

@dataclass
class TaskResult:
    """Task result data structure"""
    task_id: str
    status: str  # completed, failed
    results: Optional[Any] = None
    error: Optional[str] = None
    processing_time: Optional[float] = None
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()

class GPUTaskQueue:
    """
    Simplified single task queue manager for GPU server
    """
    
    def __init__(self):
        # Single shared queue for all dev servers
        self.pending_tasks = deque()
        self.completed_tasks = {}  # Dict for O(1) lookup: {task_id: TaskResult}
        self.connected_dev_servers = {}  # dev_server_id -> info
        self.last_poll_time = None
        self._lock = threading.RLock()
        self._completed_tasks_max_size = 1000  # Limit size to prevent memory leak
        
    def register_dev_server(self, dev_server_id: str, capabilities: List[str]) -> str:
        """Register a dev server"""
        with self._lock:
            self.connected_dev_servers[dev_server_id] = {
                "capabilities": capabilities,
                "connected_at": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat()
            }
            return "shared_queue"
    
    def add_search_task(self, task: SearchTask) -> bool:
        """Add a search task to the shared pending queue"""
        with self._lock:
            self.pending_tasks.append(task)
            queue_size = len(self.pending_tasks)
            return True
    
    def get_pending_tasks(self, max_tasks: int = 10) -> List[SearchTask]:
        """Get pending tasks from shared queue (FIFO)"""
        with self._lock:
            # Update last poll time
            self.last_poll_time = datetime.now().isoformat()
            
            tasks = []
            for _ in range(min(max_tasks, len(self.pending_tasks))):
                if self.pending_tasks:
                    tasks.append(self.pending_tasks.popleft())
            
            return tasks
    
    def peek_pending_tasks_count(self) -> int:
        """Get count of pending tasks without consuming them"""
        with self._lock:
            return len(self.pending_tasks)
    
    def submit_results(self, results: List[TaskResult]) -> bool:
        """Submit completed task results to shared queue"""
        with self._lock:
            for result in results:
                self.completed_tasks[result.task_id] = result
            
            # Cleanup old tasks if too many (keep only recent 1000)
            if len(self.completed_tasks) > self._completed_tasks_max_size:
                tasks_to_remove = len(self.completed_tasks) - self._completed_tasks_max_size
                for task_id in list(self.completed_tasks.keys())[:tasks_to_remove]:
                    del self.completed_tasks[task_id]
                logger.debug(f"Cleaned up {tasks_to_remove} old completed tasks")
                
            return True
    
    def get_task_result(self, task_id: str, remove_after_get: bool = True) -> Optional[TaskResult]:
        """Get result for a specific task from shared completed queue
        
        Args:
            task_id: Task ID to look up
            remove_after_get: If True, remove the result after getting it (default)
        """
        with self._lock:
            result = self.completed_tasks.get(task_id)
            if result and remove_after_get:
                del self.completed_tasks[task_id]
            return result
    
    async def wait_for_result_async(self, task_id: str, timeout: float = 120.0) -> Optional[TaskResult]:
        """Async version of wait_for_result that does not block the event loop."""
        start_time = time.time()
        logger.info(f"(async) Waiting for result of task {task_id} (timeout: {timeout}s)")
        poll_count = 0
        while time.time() - start_time < timeout:
            poll_count += 1
            # Get and remove result in one operation for efficiency
            result = self.get_task_result(task_id, remove_after_get=True)
            if result:
                elapsed = time.time() - start_time
                logger.info(f"(async) Found result for task {task_id} after {elapsed:.2f}s (poll #{poll_count})")
                return result
            if poll_count % 100 == 0:  # Reduce log frequency from 50 to 100
                elapsed = time.time() - start_time
                with self._lock:
                    pending_count = len(self.pending_tasks)
                    completed_count = len(self.completed_tasks)
                logger.debug(f"(async) Poll #{poll_count} for {task_id}: {elapsed:.1f}s elapsed, pending={pending_count}, completed={completed_count}")
            await asyncio.sleep(0.1)
        logger.warning(f"(async) Timeout waiting for task {task_id} result after {timeout}s")
        return None
    
    def get_queue_status(self) -> Dict[str, Any]:
        """Get status of the shared queue"""
        with self._lock:
            return {
                "queue_type": "shared",
                "pending_tasks": len(self.pending_tasks),
                "completed_tasks": len(self.completed_tasks),
                "connected_dev_servers": len(self.connected_dev_servers),
                "last_poll_time": self.last_poll_time,
                "dev_servers": list(self.connected_dev_servers.keys())
            }

class APIServerEntrypoint(BasePPOExp):
    """API Server for online inference deployment."""
    
    def __init__(self, cfg: DictConfig):
        """Initialize API server with minimal dataset requirements."""
        # Override parent init to allow optional datasets for API server
        self.cfg = cfg
        self.tokenizer = self.get_tokenizer()
        # API server can optionally load datasets for evaluation
        self.train_dataset = self.get_train_dataset()  # Will return None due to override
        self.eval_dataset = self.get_eval_dataset()    # Will load if configured
        self.colocate_pg = self.get_colocate_pg()
        
        # Store server components - initialize once at startup
        self.inference_engine_client: Optional[InferenceEngineClient] = None
        self.server_host = cfg.api_server.get("host", "0.0.0.0")
        self.server_port = cfg.api_server.get("port", 8001)
        
        # Initialize task queue for dev server communication
        self.task_queue = GPUTaskQueue()
        
        # Initialize tracker once to avoid creating multiple wandb runs
        self._tracker = None
        if cfg.trainer.get("logger"):
            logger.info("Initializing tracker for API server")
            self._tracker = self.get_tracker()
    
    def get_eval_dataset(self):
        """Initializes the evaluation dataset.

        Returns:
            PromptDataset: The evaluation dataset.
        """
        if self.cfg.data.val_data:
            prompts_dataset = PromptDataset(
                datasets=self.cfg.data.val_data,
                tokenizer=self.tokenizer,
                max_prompt_length=self.cfg.trainer.max_prompt_length,
                num_workers=8,
            )
            return prompts_dataset
        return None
        
    def get_train_dataset(self):
        """Override to avoid requiring a train dataset for API server."""
        return None
    
    async def _load_lora_if_configured(self, inference_engine_client):
        """Load LoRA adapters from disk if LoRA is configured."""
        # Check if LoRA is enabled
        if (
            hasattr(self.cfg.trainer.policy.model, "lora")
            and self.cfg.trainer.policy.model.lora.rank > 0
            and hasattr(self.cfg.trainer.policy.model.lora, "lora_sync_path")
        ):
            lora_sync_path = self.cfg.trainer.policy.model.lora.lora_sync_path
            
            # Verify the path and required files exist
            if not os.path.exists(lora_sync_path):
                logger.warning(f"LoRA sync path does not exist: {lora_sync_path}")
                return
                
            adapter_model_path = os.path.join(lora_sync_path, "adapter_model.safetensors")
            adapter_config_path = os.path.join(lora_sync_path, "adapter_config.json")
            
            if not os.path.exists(adapter_model_path):
                logger.warning(f"adapter_model.safetensors not found in {lora_sync_path}")
                return
                
            if not os.path.exists(adapter_config_path):
                logger.warning(f"adapter_config.json not found in {lora_sync_path}")
                return
            
            logger.info(f"Loading LoRA adapters from {lora_sync_path}")
            
            # Send LoRA disk loading request to inference engine
            lora_request = {
                "names": ["lora_disk_load"],
                "extras": [{"lora_disk_path": lora_sync_path}],
            }
            
            try:
                await inference_engine_client.update_named_weights(lora_request)
                logger.info(f"Successfully loaded LoRA adapters from {lora_sync_path}")
            except Exception as e:
                logger.error(f"Failed to load LoRA adapters: {e}")
                raise
        else:
            logger.info("LoRA not configured or disabled, skipping LoRA loading")

    async def initialize_engines(self):
        """Initialize inference engines and client."""
        logger.info("Initializing inference engines...")
        
        tokenizer = self.tokenizer
        
        if self.cfg.generator.run_engines_locally:
            inference_engines = create_ray_wrapped_inference_engines_from_config(
                self.cfg, self.colocate_pg, tokenizer
            )
        else:
            inference_engines = create_remote_inference_engines_from_config(self.cfg, tokenizer)
        
        # Create inference engine client without HTTP endpoint initially
        # We'll manage the HTTP endpoint manually for better control
        original_enable_http = self.cfg.generator.get("enable_http_endpoint", False)
        self.cfg.generator.enable_http_endpoint = False
        
        self.inference_engine_client = InferenceEngineClient(inference_engines, tokenizer, self.cfg)
        await self.inference_engine_client.wake_up()
        
        # Restore original setting
        self.cfg.generator.enable_http_endpoint = original_enable_http
        
        # Load LoRA adapters if configured
        await self._load_lora_if_configured(self.inference_engine_client)
        
        logger.info("Inference engines initialized successfully")

    async def start_server(self):
        """Start the HTTP API server."""
        try:
            import logging
            import uvicorn
            from fastapi import FastAPI, HTTPException
            from pydantic import BaseModel
            from typing import List, Optional
        except ImportError as e:
            logger.error(f"Missing required dependencies for API server: {e}")
            logger.error("Please install: pip install fastapi uvicorn pydantic")
            raise
        
        logger.info(f"Starting API server on {self.server_host}:{self.server_port}")
        
        # Create FastAPI app
        app = FastAPI(title="SkyRL API Server", version="1.0.0")
        
        class EvaluationRequest(BaseModel):
            data: Optional[List[dict]] = None  # Optional custom evaluation data

        class EvaluationResponse(BaseModel):
            metrics: dict
            status: str
            message: str
            detailed_results: Optional[dict] = None  # Include detailed per-example results
        
        @app.post("/evaluate", response_model=EvaluationResponse)
        async def evaluate_endpoint(request: Optional[EvaluationRequest] = None):
            """Run evaluation using custom data or pre-configured dataset"""
            try:
                # Use custom data if provided, otherwise use pre-configured dataset
                if request and request.data:
                    logger.info(f"Running evaluation with {len(request.data)} custom data points")
                    metrics, detailed_results = await self.run_evaluation_with_data(request.data)
                elif self.eval_dataset is not None:
                    logger.info("Running evaluation with pre-configured dataset")
                    metrics, detailed_results = await self.run_evaluation()
                else:
                    raise HTTPException(
                        status_code=400, 
                        detail="No evaluation data provided. Either include 'data' in request body or configure an eval dataset."
                    )
                
                logger.info("Starting evaluation...")
                logger.info(f"Evaluation completed with metrics: {metrics}")
                
                # Serialize datetime objects to strings for JSON response
                serialized_metrics = serialize_for_json(metrics)
                serialized_detailed_results = serialize_for_json(detailed_results)
                
                return EvaluationResponse(
                    metrics=serialized_metrics,
                    detailed_results=serialized_detailed_results,
                    status="success",
                    message="Evaluation completed successfully"
                )
            except Exception as e:
                logger.error(f"[EVALUATE ERROR] Evaluation failed: {e}")
                logger.error(f"[EVALUATE ERROR] Traceback:\n{traceback.format_exc()}")
                raise HTTPException(status_code=500, detail=f"Evaluation failed: {str(e)}")
        
        @app.get("/health")
        async def health_check():
            """Health check endpoint"""
            engine_status = "ready" if self.inference_engine_client is not None else "not_initialized"
            return {
                "status": "healthy", 
                "message": "API server is running",
                "inference_engine_status": engine_status
            }
        
        @app.get("/info")
        async def server_info():
            """Get server information"""
            return {
                "model": self.cfg.trainer.policy.model.path,
                "backend": self.cfg.generator.backend,
                "engines": self.cfg.generator.num_inference_engines,
                "has_eval_dataset": self.eval_dataset is not None,
                "inference_engine_ready": self.inference_engine_client is not None,
                "lora_enabled": hasattr(self.cfg.trainer.policy.model, "lora") and self.cfg.trainer.policy.model.lora.rank > 0,
            }
        
        # ============================================================================
        # Task Queue Endpoints (for dev server communication)
        # ============================================================================
        
        @app.post("/api/initialize_queue")
        async def initialize_queue(request: dict):
            """Register a dev server (simplified - single shared queue)"""
            try:
                dev_server_id = request.get("dev_server_id")
                capabilities = request.get("capabilities", [])
                
                if not dev_server_id:
                    raise HTTPException(status_code=400, detail="dev_server_id is required")
                
                queue_id = self.task_queue.register_dev_server(dev_server_id, capabilities)
                
                return {
                    "success": True,
                    "queue_id": queue_id,
                    "message": f"Dev server {dev_server_id} registered",
                    "timestamp": datetime.now().isoformat()
                }
                
            except Exception as e:
                logger.error(f"[INIT_QUEUE ERROR] Error registering dev server: {e}")
                logger.error(f"[INIT_QUEUE ERROR] Traceback:\n{traceback.format_exc()}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/api/poll_tasks")
        async def poll_tasks(queue_id: str, max_tasks: int = 10, timeout: int = 30):
            """Poll for pending tasks with long polling support"""
            try:
                start_time = time.time()
                
                # First check for immediate tasks
                tasks = self.task_queue.get_pending_tasks(max_tasks)
                
                # If no tasks found, implement long polling
                if not tasks and timeout > 0:
                    poll_interval = 0.2
                    max_wait = min(timeout, 50)
                    
                    while time.time() - start_time < max_wait:
                        await asyncio.sleep(poll_interval)
                        
                        if self.task_queue.peek_pending_tasks_count() > 0:
                            tasks = self.task_queue.get_pending_tasks(max_tasks)
                            if tasks:
                                break
                
                # Convert tasks to dict for JSON serialization
                task_dicts = [asdict(task) for task in tasks]
                
                # Serialize datetime objects in task_dicts
                task_dicts = serialize_for_json(task_dicts)
                
                elapsed = time.time() - start_time
                
                return {
                    "success": True,
                    "tasks": task_dicts,
                    "task_count": len(task_dicts),
                    "timestamp": datetime.now().isoformat(),
                    "elapsed_time": elapsed
                }
                
            except Exception as e:
                logger.error(f"Error polling tasks: {e}")
                return {
                    "success": False,
                    "error": str(e),
                    "tasks": []
                }

        @app.post("/api/submit_results")
        async def submit_results(request: dict):
            """Submit completed task results"""
            try:
                results_data = request.get("results", [])
                
                # Convert results to TaskResult objects
                results = []
                for result_data in results_data:
                    result = TaskResult(
                        task_id=result_data["task_id"],
                        status=result_data["status"],
                        results=result_data.get("results"),
                        error=result_data.get("error"),
                        processing_time=result_data.get("processing_time"),
                        timestamp=result_data.get("timestamp")
                    )
                    results.append(result)
                
                success = self.task_queue.submit_results(results)
                
                return {
                    "success": success,
                    "message": f"Submitted {len(results)} results",
                    "timestamp": datetime.now().isoformat()
                }
                
            except Exception as e:
                logger.error(f"[SUBMIT_RESULTS ERROR] Error submitting results: {e}")
                logger.error(f"[SUBMIT_RESULTS ERROR] Traceback:\n{traceback.format_exc()}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/api/queue_status")
        async def get_queue_status(queue_id: str = "shared_queue"):
            """Get queue status"""
            status = self.task_queue.get_queue_status()
            return status

        @app.get("/api/list_queues")
        async def list_queues():
            """List queue info"""
            status = self.task_queue.get_queue_status()
            return {
                "queues": {"shared_queue": status},
                "total_queues": 1
            }
        
        # ============================================================================
        # End of Task Queue Endpoints
        # ============================================================================
        
        # Set up signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, shutting down gracefully...")
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        try:
            # Configure logging
            logging.basicConfig(level=getattr(logging, "INFO"))
            
            # Create server configuration
            config = uvicorn.Config(app, host=self.server_host, port=self.server_port, log_level="info", access_log=True)
            server = uvicorn.Server(config)
            
            # Start the server directly (no asyncio.run)
            await server.serve()
        except KeyboardInterrupt:
            logger.info("Server stopped by user")
        except Exception as e:
            logger.error(f"Server error: {e}")
            raise
            
    async def run_evaluation(self) -> tuple[dict[str, Any], dict[str, Any]]:
        """Run evaluation using the same logic as main_generate.py with shared inference engine
        
        Returns:
            tuple: (metrics, detailed_results)
        """
        assert self.eval_dataset is not None, "The evaluation requires an eval dataset to be provided"

        # Ensure inference engine is initialized
        if self.inference_engine_client is None:
            logger.info("Inference engine not initialized, initializing now...")
            await self.initialize_engines()
        
        generator = self.get_generator(self.cfg, self.tokenizer, self.inference_engine_client)

        results: dict[str, Any] = await evaluate(
            eval_dataloader=build_dataloader(self.cfg, self.eval_dataset, is_train=False),
            generator=generator,
            cfg=self.cfg,
            global_step=None,
            tokenizer=self.tokenizer,
        )

        # Log to tracker if initialized (reuse the same wandb run)
        if self._tracker is not None:
            self._tracker.log(results, step=0, commit=True)

        # Extract detailed results if available
        detailed_results = results.pop('detailed_results', None)

        return results, detailed_results

    async def run_evaluation_with_data(self, custom_data: List[dict]) -> tuple[dict[str, Any], dict[str, Any]]:
        """Run evaluation using custom data provided in API request with shared inference engine
        
        Returns:
            tuple: (metrics, detailed_results)
        """
        
        # Create a temporary dataset from the custom data
        temp_dataset = self.create_temp_dataset_from_data(custom_data)
        
        # Ensure inference engine is initialized
        if self.inference_engine_client is None:
            await self.initialize_engines()
        
        generator = self.get_generator(self.cfg, self.tokenizer, self.inference_engine_client)

        results: dict[str, Any] = await evaluate(
            eval_dataloader=build_dataloader(self.cfg, temp_dataset, is_train=False),
            generator=generator,
            cfg=self.cfg,
            global_step=None,
            tokenizer=self.tokenizer,
        )

        # Log to tracker if initialized (reuse the same wandb run)
        if self._tracker is not None:
            self._tracker.log(results, step=0, commit=True)

        # Extract detailed results if available  
        detailed_results = results.pop('detailed_results', None)

        return results, detailed_results
    
    def create_temp_dataset_from_data(self, custom_data: List[dict]) -> PromptDataset:
        """Create a temporary PromptDataset from custom data"""
        import tempfile
        import json
        import requests
        
        # Validate data format
        for i, item in enumerate(custom_data):
            if 'prompt' not in item:
                raise ValueError(f"Item {i} missing required 'prompt' field")
            
            # Set default values for required fields if not present
            if 'data_source' not in item:
                item['data_source'] = f'custom_api_data_{i}'
            if 'env_class' not in item:
                item['env_class'] = self.cfg.environment.get('env_class', 'search')
            if 'ability' not in item:
                item['ability'] = 'fact-reasoning'  # Default for search tasks
            
            # Ensure reward_spec has correct format
            if 'reward_spec' not in item:
                # For online data without ground truth, use a placeholder
                item['reward_spec'] = {
                    "ground_truth": {"target": ["placeholder_answer"]},
                    "style": "rule"
                }
            elif 'ground_truth' not in item['reward_spec']:
                # Convert old format to new format if needed
                if 'method' in item['reward_spec']:
                    old_gt = item['reward_spec'].get('ground_truth', 'placeholder_answer')
                    item['reward_spec'] = {
                        "ground_truth": {"target": [str(old_gt)]},
                        "style": item['reward_spec'].get('method', 'rule')
                    }
                else:
                    # Use placeholder for online data
                    item['reward_spec'] = {
                        "ground_truth": {"target": ["placeholder_answer"]},
                        "style": "rule"
                    }
            
            # Ensure extra_info has the expected structure
            if 'extra_info' not in item:
                item['extra_info'] = {}
                
            # Set required extra_info fields
            extra_info = item['extra_info']
            if 'index' not in extra_info:
                extra_info['index'] = i
            if 'need_tools_kwargs' not in extra_info:
                extra_info['need_tools_kwargs'] = True
            if 'split' not in extra_info:
                extra_info['split'] = 'custom_eval'
            
            # Create tools_kwargs if not present
            if 'tools_kwargs' not in extra_info:
                question = extra_info.get('question', 'Custom evaluation question')
                # Use placeholder ground truth for online data
                ground_truth_for_tools = item['reward_spec']['ground_truth']
                extra_info['tools_kwargs'] = {
                    "search": {
                        "create_kwargs": {
                            "data_source": item['data_source'],
                            "ground_truth": ground_truth_for_tools,
                            "question": question
                        }
                    }
                }
            
            # Ensure metadata exists
            if 'metadata' not in item:
                item['metadata'] = None
        
        # Create a temporary JSON file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            for item in custom_data:
                f.write(json.dumps(item) + '\n')
            temp_file_path = f.name
        
        try:
            # Create PromptDataset from the temporary file
            temp_dataset = PromptDataset(
                datasets=[temp_file_path],
                tokenizer=self.tokenizer,
                max_prompt_length=self.cfg.trainer.max_prompt_length,
                num_workers=1,  # Use single worker for small custom datasets
            )
            
            logger.info(f"Created temporary dataset with {len(temp_dataset)} items from custom data")
            return temp_dataset
            
        finally:
            # Clean up temporary file
            import os
            try:
                os.unlink(temp_file_path)
            except Exception as e:
                logger.warning(f"Failed to clean up temporary file {temp_file_path}: {e}")

    async def run(self) -> None:
        """Run the API server."""
        try:
            # Initialize engines once at startup
            await self.initialize_engines()
            
            # Start the server
            await self.start_server()
        except Exception as e:
            logger.error(f"Failed to start API server: {e}")
            raise


@ray.remote(num_cpus=1)
def api_server_entrypoint(cfg: DictConfig):
    """Ray remote function to run API server."""
    server = APIServerEntrypoint(cfg)
    return asyncio.run(server.run())


def start_api_server_sync(cfg: DictConfig):
    """Synchronous wrapper to start API server."""
    server = APIServerEntrypoint(cfg)
    asyncio.run(server.run())


@hydra.main(config_path=config_dir, config_name="api_server_config", version_base=None)
def main(cfg: DictConfig) -> None:
    """Main entry point for API server."""
    # Validate generator configuration
    validate_generator_cfg(cfg)
    
    # Initialize Ray
    initialize_ray(cfg)
    
    try:
        if cfg.get("use_ray_remote", False):
            # Run in Ray remote mode (for distributed deployment)
            ray.get(api_server_entrypoint.remote(cfg))
        else:
            # Run directly (for single-node deployment)
            start_api_server_sync(cfg)
    except KeyboardInterrupt:
        logger.info("API Server stopped by user")
    except Exception as e:
        logger.error(f"API Server failed: {e}")
        raise
    finally:
        logger.info("API Server shutdown complete")


if __name__ == "__main__":
    main()
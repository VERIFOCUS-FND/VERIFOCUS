import json
import logging
import requests
import uuid
import time
import threading
from typing import Tuple, Optional, Any, Dict
from urllib.parse import urlparse

from skyrl_gym.tools.core import tool, ToolGroup

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

DEFAULT_TIMEOUT = 90
MAX_RETRIES = 10
INITIAL_RETRY_DELAY = 5


def call_search_api(
    retrieval_service_url: str,
    query: str,
    topk: int = 3,
    return_scores: bool = True,
    doc_id = None,
    timeout: int = DEFAULT_TIMEOUT,
    log_requests: bool = True,
    session: Optional[requests.Session] = None,
) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:

    request_id = str(uuid.uuid4())
    log_prefix = f"[Search Request ID: {request_id}] "

    payload = {"query": query, "topk": topk, "doc_id": doc_id, "return_scores": return_scores}
    headers = {"Content-Type": "application/json", "Accept": "application/json"}

    # Use provided session or create a new one for this request
    if session is None:
        session = requests.Session()
        should_close_session = True
    else:
        should_close_session = False

    last_error = None
    for attempt in range(MAX_RETRIES):
        try:
            if log_requests:
                logger.info(
                    f"{log_prefix}Attempt {attempt + 1}/{MAX_RETRIES}: Calling search API at {retrieval_service_url}"
                )
            response = session.post(
                retrieval_service_url,
                headers=headers,
                json=payload,
                timeout=timeout,
            )

            if response.status_code in [500, 502, 503, 504]:
                last_error = f"{log_prefix}API Request Error: Server Error ({response.status_code}) on attempt {attempt + 1}/{MAX_RETRIES}"
                logger.warning(last_error)
                if attempt < MAX_RETRIES - 1:
                    delay = INITIAL_RETRY_DELAY * (attempt + 1)
                    logger.info(f"{log_prefix}Retrying after {delay} seconds...")
                    time.sleep(delay)
                continue

            response.raise_for_status()

            if log_requests:
                logger.info(f"{log_prefix}Search API call successful on attempt {attempt + 1}")

            if should_close_session:
                session.close()

            return response.json(), None

        except requests.exceptions.ConnectionError as e:
            last_error = f"{log_prefix}Connection Error: {e}"
            logger.warning(last_error)
            if attempt < MAX_RETRIES - 1:
                delay = INITIAL_RETRY_DELAY * (attempt + 1)
                logger.info(f"{log_prefix}Retrying after {delay} seconds...")
                time.sleep(delay)
            continue
        except requests.exceptions.Timeout as e:
            last_error = f"{log_prefix}Timeout Error: {e}"
            logger.warning(last_error)
            if attempt < MAX_RETRIES - 1:
                delay = INITIAL_RETRY_DELAY * (attempt + 1)
                logger.info(f"{log_prefix}Retrying after {delay} seconds...")
                time.sleep(delay)
            continue
        except requests.exceptions.RequestException as e:
            last_error = f"{log_prefix}API Request Error: {e}"
            break  
        except json.JSONDecodeError as e:
            raw_response_text = response.text if "response" in locals() else "N/A"
            last_error = f"{log_prefix}API Response JSON Decode Error: {e}, Response: {raw_response_text[:200]}"
            break  
        except Exception as e:
            last_error = f"{log_prefix}Unexpected Error: {e}"
            break  

    logger.error(f"{log_prefix}API Request Failed after {MAX_RETRIES} attempts: {last_error}")


    if should_close_session:
        session.close()

    return None, last_error

def queryfocusedsummarizer(news_article, query, documents):
    '''Use this function to process content within <information> tags for query-focused summarization.'''
    PROMPT_TEMPLATE_SYS = """**TASK:**
Synthesize the key information from the **[Retrieved Documents]** that is relevant to the **[Current Query]**, in order to support downstream **fact-checking** of the **[News Article]**.

**INSTRUCTIONS:**
1.  **Extract & Merge:** Identify all relevant facts (e.g., dates, events, statistics, direct statements, attributed claims) and combine them. Eliminate redundancy. You should provide information for fact-checking the news article, not just answer to current query.
2.  **Provide Information, Not an Answer:** Your output should be a self-contained block of information, NOT a direct, short answer to the current query.
3.  **Handle Insufficient Information:** If the documents do not contain relevant information for the query, state that the provided sources are insufficient and suggest that further investigation may be needed. You can also provide some further investigation direction and query rewrite suggestions.
4.  **Format:** Return the entire synthesized output only. Add no other text.

"""
    PROMPT_TEMPLATE_USER = """
**CONTEXT:**
- **[News Article]:** {news_article}
- **[Current Query]:** {query}
- **[Retrieved Documents]:** {documents}

**TASK:**
Synthesize the key information from the **[Retrieved Documents]** that is relevant to the **[Current Query]**, in order to support downstream **fact-checking** of the **[News Article]**.

**INSTRUCTIONS:**
1.  **Extract & Merge:** Identify all relevant facts (e.g., dates, events, statistics, direct statements, attributed claims) and combine them. Eliminate redundancy. You should provide information for fact-checking the news article, not just answer to current query.
2.  **Provide Information, Not an Answer:** Your output should be a self-contained block of information, NOT a direct, short answer to the current query.
3.  **Handle Insufficient Information:** If the documents do not contain relevant information for the query, state that the provided sources are insufficient and suggest that further investigation may be needed. You can also provide some further investigation direction and query rewrite suggestions.
4.  **Format:** Return the entire synthesized output only. Add no other text.

**SYNTHESIZED INFORMATION:**
"""
    messages = [
        {"role": "system", "content": PROMPT_TEMPLATE_SYS},
        {"role": "user", "content": PROMPT_TEMPLATE_USER.format(
            news_article=news_article,
            query=query,
            documents=documents
        )}
    ]
    return messages 



def _passages2string(retrieval_result):
    format_reference = ""
    for idx, doc_item in enumerate(retrieval_result):
        content = doc_item["document"]["contents"].strip()
        format_reference += f"Doc {idx+1}: {content}\n"
    return format_reference


class SearchToolGroup(ToolGroup):

    _session_pool = {}
    _session_lock = threading.Lock()
    
    _kw_model = None
    _kw_model_lock = threading.Lock()

    @classmethod
    def _get_shared_session(cls, base_url: str) -> requests.Session:

        with cls._session_lock:
            if base_url not in cls._session_pool:
                session = requests.Session()

                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=20,  
                    pool_maxsize=20,  
                    max_retries=0,  
                    pool_block=False,  
                )
                session.mount("http://", adapter)
                session.mount("https://", adapter)
                cls._session_pool[base_url] = session
                logger.info(f"Created shared session pool for {base_url}")
            return cls._session_pool[base_url]
    
    @classmethod
    def _get_shared_keybert_model(cls):
        """Get or create a shared KeyBERT model instance"""
        if cls._kw_model is None:
            with cls._kw_model_lock:

                if cls._kw_model is None:
                    try:
                        from keybert import KeyBERT
                        cls._kw_model = KeyBERT()
                        logger.info("Created shared KeyBERT model instance")
                    except ImportError as e:
                        logger.error(f"Failed to import KeyBERT: {e}")
                        return None
        return cls._kw_model


    def __init__(self, search_url="http://127.0.0.1:8000/retrieve", summarizer_url="http://127.0.0.1:6001", topk=3, timeout=DEFAULT_TIMEOUT, log_requests=True, enable_summarization=True, enable_query_rewrite=True, query_rewrite_method="keybert"):
        self.search_url = search_url
        self.summarizer_url = summarizer_url
        self.topk = topk
        self.timeout = timeout
        self.log_requests = log_requests
        self.enable_summarization = enable_summarization
        self.enable_query_rewrite = enable_query_rewrite
        self.query_rewrite_method = query_rewrite_method
        if self.enable_query_rewrite and self.query_rewrite_method in ["keybert"]:
            self.kw_model = self._get_shared_keybert_model()
            if self.kw_model is None:
                logger.error("Failed to initialize KeyBERT model. Query rewriting with keybert will be disabled.")
                self.enable_query_rewrite = False
        parsed_url = urlparse(self.search_url)
        self.base_url = f"{parsed_url.scheme}://{parsed_url.netloc}"

        # Get shared session for this base URL
        self.session = self._get_shared_session(self.base_url)
        if self.log_requests:
            logger.info(f"SearchToolGroup initialized using shared session pool for {self.base_url}")
        
        # check the query focused summarizer api is running
        if self.enable_summarization or self.enable_query_rewrite:
            try:
                health_path = "/ping"
                health_url = f"{self.summarizer_url}{health_path}"
                for attempt in range(3):
                    try:
                        resp = self.session.get(health_url, timeout=5)
                        if resp.status_code == 200:
                            break
                        else:
                            logger.warning(
                                f"Query-focused summarizer API returned status {resp.status_code} on attempt {attempt+1}/3"
                            )
                    except Exception as e:
                        logger.warning(
                            f"Query-focused summarizer API health check attempt {attempt+1}/3 failed: {e}"
                        )
                    time.sleep(2)
            except Exception:
                logger.debug("Query-focused summarizer health check skipped due to unexpected error")
        else:
            logger.info("Query-focused summarization and query rewrite is disabled.")
        

        super().__init__(name="SearchToolGroup")

    @tool
    def search(self, query, news_article, doc_id) -> str:
        if query is None:
            return ""

        query = query.strip()

        if self.enable_query_rewrite:

            if self.query_rewrite_method == "keybert":
                kws = self.kw_model.extract_keywords(
                    query,
                    keyphrase_ngram_range=(1, 2),
                    stop_words="english",
                    top_n=5,
                    use_mmr=True,
                    diversity=0.5,
                )

                keywords = [kw for kw, score in kws]

                seen_words = set()
                unique_words = []
                for keyword in keywords:
                    for word in keyword.split():
                        word_lower = word.lower()
                        if word_lower not in seen_words:
                            seen_words.add(word_lower)
                            unique_words.append(word)
                rewritten_query = " ".join(unique_words)
                query = rewritten_query
                            
                
        try:
            api_response, error_msg = call_search_api(
                retrieval_service_url=self.search_url,
                query=query,
                topk=self.topk,
                doc_id = doc_id,
                timeout=self.timeout,
                log_requests=self.log_requests,
                session=self.session, 
            )
        except Exception as e:
            error_msg = f"API Request Exception during batch search: {e}"
            logger.error(f"Batch search: {error_msg}")

        metadata = {
            "query": query,
            "doc_id": doc_id,
            "api_request_error": error_msg,
            "api_response": None,
            "status": "unknown",
            "total_results": 0,
            "formatted_result": None,
        }

        result_text = json.dumps({"result": "Search request failed or timed out after retries."})

        if error_msg:
            metadata["status"] = "api_error"
            result_text = json.dumps({"result": f"Search error: {error_msg}"})
            logger.error(f"Batch search: API error occurred: {error_msg}")
        elif api_response:
            logger.debug(f"Batch search: API Response: {api_response}")
            metadata["api_response"] = api_response

            try:
                raw_results = api_response.get("result", [])
                if raw_results:
                    pretty_results = []
                    total_results = 0
                    for retrieval in raw_results:
                        formatted = _passages2string(retrieval)
                        pretty_results.append(formatted)
                        total_results += len(retrieval) if isinstance(retrieval, list) else 1

                    final_result = "\n---\n".join(pretty_results)
                    result_text = json.dumps({"result": final_result})
                    metadata["status"] = "success"
                    metadata["total_results"] = total_results
                    metadata["formatted_result"] = final_result
                    if self.log_requests:
                        logger.info(f"Batch search: Successful, got {total_results} total results")
                    
                    if self.enable_summarization:
                        
                        messages_content = queryfocusedsummarizer(
                            news_article=news_article,
                            query=query,
                            documents=final_result
                        )
                        
                        summarization_payload = {
                            "model": "Qwen/Qwen3-8B",
                            "messages": messages_content,
                            "temperature": 0.6,
                            "top_p": 0.95,
                            "top_k": 20,
                            "max_tokens": 1000,
                            "chat_template_kwargs": {"enable_thinking": False}
                        }
                        last_error = None
                        for attempt in range(MAX_RETRIES):
                            try:
                                if self.log_requests:
                                    logger.info(f"Summarization attempt {attempt + 1}/{MAX_RETRIES}")
                                summarization_response = self.session.post(
                                    self.summarizer_url + "/v1/chat/completions",
                                    headers={"Content-Type": "application/json", "Accept": "application/json"},
                                    json=summarization_payload,
                                    timeout=self.timeout,
                                )
                                
                                # Check for Gateway Timeout (504) and other server errors for retrying
                                if summarization_response.status_code in [500, 502, 503, 504]:
                                    last_error = f"Summarization API Server Error ({summarization_response.status_code}) on attempt {attempt + 1}/{MAX_RETRIES}"
                                    logger.warning(last_error)
                                    if attempt < MAX_RETRIES - 1:
                                        delay = INITIAL_RETRY_DELAY * (attempt + 1)
                                        logger.info(f"Retrying summarization after {delay} seconds...")
                                        time.sleep(delay)
                                    continue
                                
                                summarization_response.raise_for_status()
                                response_data = summarization_response.json()
                                summary = response_data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
                                if summary:
                                    result_text = json.dumps({"result": summary})
                                    metadata["status"] = "success_with_summarization"
                                    if self.log_requests:
                                        logger.info(f"Batch search: Summarization successful on attempt {attempt + 1}")
                                    break
                                else:
                                    if self.log_requests:
                                        logger.warning("Batch search: Summarization returned empty result")
                                    break
                                    
                            except requests.exceptions.ConnectionError as e:
                                last_error = f"Summarization Connection Error: {e}"
                                logger.warning(last_error)
                                if attempt < MAX_RETRIES - 1:
                                    delay = INITIAL_RETRY_DELAY * (attempt + 1)
                                    logger.info(f"Retrying summarization after {delay} seconds...")
                                    time.sleep(delay)
                                continue
                            except requests.exceptions.Timeout as e:
                                last_error = f"Summarization Timeout Error: {e}"
                                logger.warning(last_error)
                                if attempt < MAX_RETRIES - 1:
                                    delay = INITIAL_RETRY_DELAY * (attempt + 1)
                                    logger.info(f"Retrying summarization after {delay} seconds...")
                                    time.sleep(delay)
                                continue
                            except requests.exceptions.RequestException as e:
                                last_error = f"Summarization API Request Error: {e}"
                                break  # Exit retry loop on other request errors
                            except json.JSONDecodeError as e:
                                raw_response_text = summarization_response.text if "summarization_response" in locals() else "N/A"
                                last_error = f"Summarization API Response JSON Decode Error: {e}, Response: {raw_response_text[:200]}"
                                break  # Exit retry loop on JSON decode errors
                            except Exception as e:
                                last_error = f"Summarization Unexpected Error: {e}"
                                break  # Exit retry loop on other unexpected errors
                        
                        if last_error:
                            error_msg = f"Summarization API failed after {MAX_RETRIES} attempts: {last_error}"
                            logger.error(f"Batch search: {error_msg}")
                
                else:
                    result_text = json.dumps({"result": "No search results found."})
                    metadata["status"] = "no_results"
                    metadata["total_results"] = 0
                    if self.log_requests:
                        logger.info("Batch search: No results found")
            except Exception as e:
                error_msg = f"Error processing search results: {e}"
                result_text = json.dumps({"result": error_msg})
                metadata["status"] = "processing_error"
                logger.error(f"Batch search: {error_msg}")
        else:
            metadata["status"] = "unknown_api_state"
            result_text = json.dumps({"result": "Unknown API state (no response and no error message)."})
            logger.error("Batch search: Unknown API state.")

        return result_text

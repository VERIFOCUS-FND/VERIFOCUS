import asyncio
import re
from typing import Any, Dict, List, Optional
from omegaconf import DictConfig

from skyrl_gym.envs.base_text_env import BaseTextEnv, BaseTextEnvStepOutput, ConversationType
from skyrl_gym.envs.search.utils import compute_score


class SearchQueryPending(Exception):
    """Exception raised when a search query needs to be sent to the client."""
    
    def __init__(self, query: str, session_id: str):
        self.query = query
        self.session_id = session_id
        super().__init__(f"Search query pending for session {session_id}: {query}")


class InteractiveSearchEnv(BaseTextEnv):
    """
    Environment for interactive search execution where search results 
    are provided by the client instead of calling an internal search API.
    """
    
    def __init__(self, env_config: DictConfig, extras: Dict[str, Any] = {}):
        super().__init__()
        
        assert "reward_spec" in extras, "reward_spec field is required"
        assert "ground_truth" in extras["reward_spec"], "ground_truth is required in reward_spec field"
        self.ground_truth = extras["reward_spec"]["ground_truth"]
        self.max_turns = extras["max_turns"] if "max_turns" in extras else 2
        
        # Session ID for tracking this conversation
        self.session_id = extras.get("session_id", "default_session")
        
        # Chat history
        self.chat_history: ConversationType = []
        
        # Pending search results storage
        self.pending_search_results: Dict[str, str] = {}
        self.waiting_for_search = False
        self.current_query = None
    
    def _parse_action(self, action: str) -> List[Optional[str]]:
        """Parse search query from action."""
        match = None
        if "<search>" in action and "</search>" in action:
            match = re.search(r"<search>(.*?)</search>", action, re.DOTALL)
        return [match.group(1).strip()] if match else [None]
    
    def _get_reward(self, action: str, done: bool) -> float:
        """Calculate reward based on final answer."""
        if done:
            # Concat all chat history into a single string and compute reward
            chat_history_str = "".join([item["content"] for item in self.chat_history])
            return compute_score(chat_history_str, self.ground_truth)
        else:
            # No reward for intermediate steps
            return 0
    
    def _is_done(self, action: str) -> bool:
        """Check if the episode is done."""
        if self.turns >= self.max_turns:
            return True
        return "<answer>" in action and "</answer>" in action
    
    def _validate_action(self, action: str):
        """Validate that stop tags are at the end of the action."""
        stop_tags = ["</search>", "</answer>"]
        for tag in stop_tags:
            if tag in action:
                assert action.split(tag, 1)[1] == "", (
                    f"{tag} detected in the response but it is not the last string generated. "
                    f"Use {stop_tags} as stop strings in the configuration."
                )
    
    def provide_search_result(self, query: str, search_result: str):
        """Called by the API server to provide search results for a pending query."""
        self.pending_search_results[query] = search_result
        self.waiting_for_search = False
    
    def step(self, action: str) -> BaseTextEnvStepOutput:
        """Process one step of the environment."""
        self.turns += 1
        self._validate_action(action)
        self.chat_history.append({"role": "assistant", "content": action})
        
        error = None
        done = self._is_done(action)
        reward = self._get_reward(action, done)
        
        if done:
            return BaseTextEnvStepOutput(observations=[], reward=reward, done=done, metadata={})
        
        # Check if this action contains a search query
        queries = self._parse_action(action)
        query = queries[0] if queries and queries[0] else None
        
        if query:
            self.current_query = query
            # Check if we already have results for this query
            if query in self.pending_search_results:
                # Use cached result
                search_result = self.pending_search_results[query]
                observation = f"\n<information>{search_result}</information>\n"
                
                # Clean up the cached result
                del self.pending_search_results[query]
            else:
                # Need to request search results from client
                self.waiting_for_search = True
                # Raise special exception to signal that we need client input
                raise SearchQueryPending(query, self.session_id)
        else:
            # No search query in this action, continue normally
            observation = None
        
        # Wrap the observation properly as a message
        if observation:
            new_obs = {"role": "user", "content": observation}
        elif error:
            new_obs = {"role": "user", "content": error}
        else:
            new_obs = None
        
        info = {
            "session_id": self.session_id,
            "query": query,
            "waiting_for_search": self.waiting_for_search
        }
        
        # Update chat history
        if new_obs:
            self.chat_history.append(new_obs)
        
        return BaseTextEnvStepOutput(
            observations=[new_obs] if new_obs else [],
            reward=reward,
            done=done,
            metadata=info,
        )